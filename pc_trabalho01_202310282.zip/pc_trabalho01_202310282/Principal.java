/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 22/03/2024
* Ultima alteracao.: 25/03/2024
* Nome.............: Principal
* Funcao...........: O programa tem a funcao de simular o andamento e controle simultaneo de 2 trens (naves), em diferentes posicoes de inicio.
*                   
****************************************************************/

import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.layout.AnchorPane;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.animation.PathTransition;
import javafx.animation.Interpolator;
import javafx.animation.Timeline;
import javafx.util.Duration;
//fim da listagem de importacoes de bibliotecas utilizadas

public class Principal extends Application
{
  public static void main(String[] args)
  {
    launch(args);
  }
  //main iniciando o javaFX

  @Override
  /***************************************************************
   * Metodo: start
   * Funcao: Comeca o javaFX
   * Parametros:
   * - primaryStage: tela inicial do programa
   * Retorno: void
   ******************************************************************/
  public void start(Stage primaryStage) throws Exception
  {
  //primeiramente o botao de inicio e aparencia da tela --------------------------------------------------------

    Stage window = primaryStage; //atribuimos a variavel window ao primaryStage, para facilitar a leitura do codigo

    window.setTitle("Star Trains"); //Cria um stage para tela de inicio

    Image telainicio = new Image("file:Img/Star-wars-logo.jpg"); //define qual imagem sera utilizada na tela incial
    ImageView telainicio_view = new ImageView(telainicio); //cria um imageview dessa imagem

    telainicio_view.setFitHeight(900*0.83);// define a altura da imagem
    telainicio_view.setFitWidth(900*0.83);// define a largura da imagem

    AnchorPane layout = new AnchorPane(); //cria um painel para janela
    layout.getChildren().add(telainicio_view); //adiciona a imagem ao layout

    Button button = new Button(); //cria um botao
    button.setText("Comecar"); //adiciona o texto do botao
    layout.getChildren().add(button); //adciona o botao ao layout

    button.setPrefWidth(100); //define a largura do botao
    button.setPrefHeight(50); //define a altura do botao

    Scene scene = new Scene(layout); //cria uma cena para ser setada na janela
    window.setScene(scene); //seta a cena definida

    Image icon = new Image("file:Img/Star-wars-logo.jpg"); //define a imagem que sera usada no icone da pagina
    window.getIcons().add(icon); //adiciona o icone definido na pagina

    AnchorPane.setTopAnchor(button, 750.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(button, 400.0*0.83); //define a largura que o botao vai estar

    Image secondScreen = new Image("file:Img/telainicio.jpeg"); //cria outra imagem para ser usada na proxima janela
    ImageView secondScreen_view = new ImageView(secondScreen); //cria um imageview para o layout2

    AnchorPane layout2  = new AnchorPane(); // cria o segundo layout para proxima janela
    layout2.getChildren().add(secondScreen_view); //adiciona a imagem ao segundo layout

    secondScreen_view.setFitHeight(900*0.83);// define a altura da imagem
    secondScreen_view.setFitWidth(900*0.83);// define a largura da imagem

    Scene scene2 = new Scene(layout2); //cria a proxima janela

    button.setOnAction(e -> window.setScene(scene2)); //muda para a proxima janela

    AnchorPane layout3  = new AnchorPane(); //cria um novo layout para nova cena
    Scene scene3 = new Scene(layout3); //cria a cena dos trilhos

    Image espaco = new Image("Img/espaco.png");
    ImageView espaco_view = new ImageView(espaco);

    espaco_view.setFitHeight(900*0.83);// define a altura da imagem
    espaco_view.setFitWidth(900*0.83);// define a largura da imagem

    layout3.getChildren().add(espaco_view); //adiciona uma imagem ao layout
    
    //agora a criacao de 4 botoes para selecionar os possiveis caminhos--------------------------------------------------------------------------------------------

    Button path1 = new Button(); //cria um botao
    path1.setText("Millenium Falcon em baixo e X-Wing em cima"); //adiciona o texto ao botao
    layout2.getChildren().add(path1); //adiciona o botao ao layout

    path1.setPrefHeight(50); //define a altura do botao
    path1.setPrefWidth(500); //define a largura do botao

    AnchorPane.setTopAnchor(path1, 250.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path1, 150.0*0.83); //define a largura que o botao vai estar   

    Button path2 = new Button(); //cria um botao
    path2.setText("Millenium Falcon em cima e X-Wing em baixo"); //adiciona o texto ao botao
    layout2.getChildren().add(path2); //adiciona o botao ao layout

    path2.setPrefHeight(50); //define a altura do botao
    path2.setPrefWidth(500); //define a largura do botao

    AnchorPane.setTopAnchor(path2, 350.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path2, 150.0*0.83); //define a largura que o botao vai estar 

    Button path3 = new Button(); //cria um botao
    path3.setText("As duas naves em cima"); //adiciona o texto ao botao
    layout2.getChildren().add(path3); //adiciona o botao ao layout

    path3.setPrefHeight(50); //define a altura do botao
    path3.setPrefWidth(200); //define a largura do botao

    AnchorPane.setTopAnchor(path3, 450.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path3, 325.0*0.83); //define a largura que o botao vai estar 

    Button path4 = new Button(); //cria um botao
    path4.setText("As duas naves em baixo"); //adiciona o texto ao botao
    layout2.getChildren().add(path4); //adiciona o botao ao layout

    path4.setPrefHeight(50); //define a altura do botao
    path4.setPrefWidth(200); //define a largura do botao

    AnchorPane.setTopAnchor(path4, 550.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path4, 325.0*0.83); //define a largura que o botao vai estar 

    //agora o andamento e controle dos trens (naves) junto as escolhas possiveis -----------------------------------------------------------------------------------------

    Image mf = new Image("Img/starwarsmillenniumfalcon3.png"); //imagem da milennium falcon
    Image xwing = new Image("Img/230911103258-01-star-wars-starfighter-model.png"); //imagem da x-wing

    ImageView mf_view = new ImageView(mf); //cria o view da milennium falcon
    ImageView xwing_view = new ImageView(xwing); //cria o view da xwing

    layout3.getChildren().add(mf_view); //adiciona a milennium falcon no layout

    mf_view.setFitHeight(100*0.83);// define a altura da imagem
    mf_view.setFitWidth(100*0.83);// define a largura da imagem

    layout3.getChildren().add(xwing_view); //adiciona a x-wing no layout

    xwing_view.setFitHeight(100*0.83);// define a altura da imagem
    xwing_view.setFitWidth(100*0.83);// define a largura da imagem

    //agora um botao para retornar para pagina anterior ----------------------------------------------------------------------------------

    Button back = new Button(); //cria um botao para retornar para cena anterior
    back.setText("Voltar"); //define o texto do botao
    layout3.getChildren().add(back); //adiciona o botao ao layout

    back.setPrefWidth(100); //define a largura do botao
    back.setPrefHeight(50); //define a altura do botao

    AnchorPane.setTopAnchor(back, 550.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(back, 750.0*0.83); //define a largura que o botao vai estar

    Button back2 = new Button(); //cria um botao para retornar para cena anterior
    back2.setText("Voltar"); //define o texto do botao
    layout2.getChildren().add(back2); //adiciona o botao ao layout

    back2.setOnAction(e -> window.setScene(scene)); //faz voltar uma cena

    back.setPrefWidth(100); //define a largura do botao
    back.setPrefHeight(50); //define a altura do botao

    AnchorPane.setTopAnchor(back2, 550.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(back2, 750.0*0.83); //define a largura que o botao vai estar

     //agora as variaveis para animacoes para seguir os caminhos corretamente -----------------------------------------------------------

     Path inferior_esquerda = inferiorEsquerda(); //criacao de variavel para  o caminho indicado no metodo que ela recebe
     Path superior_direita = superiorDireita(); //criacao de variavel para  o caminho indicado no metodo que ela recebe
     Path superior_esquerda = superiorEsquerda(); //criacao de variavel para  o caminho indicado no metodo que ela recebe
     Path inferior_direita = inferiorDireita(); //criacao de variavel para  o caminho indicado no metodo que ela recebe
     PathTransition pathTransition = new PathTransition(); //cria os "controladores" de animacao  para uma das naves
     PathTransition pathTransition2 = new PathTransition(); //cria os "controladores" de animacao  para uma das naves

     //agora o botao de resetar o programa -----------------------------------------------------------------------------------------------

    Button reset = new Button(); //cria o botao para resetar a animacao
    reset.setText("Reiniciar"); //adiciona o texto ao botao
    layout3.getChildren().add(reset); //adiciona o botao ao layout do espaco

    AnchorPane.setTopAnchor(reset, 0.0*0.83); //define a alutra que o botao reset vai estar
    AnchorPane.setLeftAnchor(reset, 800.0*0.83); //define a largura que o botao reset vai estar
    //agora o slider de controle de velocidade --------------------------------------------------------------------------------------------

    Slider sliderMF = new Slider(); //cria o slider para milennium falcon
    sliderMF.setMin(0); //define o valor minimo da velocidade
    sliderMF.setMax(100); //define o valor maximo da velocidade

    Slider sliderX = new Slider(); // cria o slider para x-wing
    sliderX.setMin(0); //define o valor minimo da velocidade
    sliderX.setMax(100); //define o valor maximo da velocidade

    layout3.getChildren().add(sliderMF); //adiciona o slider da milennium falcon ao layout 
    layout3.getChildren().add(sliderX); //adiciona o slider da x-wing ao layout 

    AnchorPane.setTopAnchor(sliderMF, 850.0*0.83); //define a alutra que o slider da milennium falcon vai estar
    AnchorPane.setLeftAnchor(sliderMF, 100.0*0.83); //define a largura que o slider da milennium falcon vai estar

    AnchorPane.setTopAnchor(sliderX, 850.0*0.83); //define a alutra que o slider da x-wing vai estar
    AnchorPane.setLeftAnchor(sliderX, 725.0*0.83); //define a largura que o slider da x-wing vai estar

    sliderMF.setShowTickMarks(true); //mostra as marcacoes ao longo do slider
    sliderMF.setShowTickLabels(true); //mostra os numeros ao longo do slider

    sliderX.setShowTickLabels(true); //mostra os numeros ao longo do slider
    sliderX.setShowTickMarks(true); //mostra as marcacoes ao longo do slider
    
    //agora a criacao de um botao para confirmar a velocidade

    //agora o codigo para selecionar os possiveis caminhos ------------------------------------------------------------------------------

    path1.setOnAction(e -> {
      animation(window, scene3, scene2, reset, xwing_view, mf_view, layout3, inferior_esquerda, pathTransition, 
      superior_direita, pathTransition2, back, sliderMF, sliderX); //incia a animacao na posicao 1
    });

    path2.setOnAction(e -> {
      animation(window, scene3, scene2,  reset, xwing_view, mf_view , layout3, inferior_direita, pathTransition,
      superior_esquerda, pathTransition2, back,  sliderMF, sliderX); //incia a animacao na posicao 2
    });

    path3.setOnAction(e -> {
      animation(window, scene3, scene2,  reset, mf_view, xwing_view, layout3, superior_direita, pathTransition,
      superior_esquerda, pathTransition2, back,  sliderMF, sliderX); //incia a animacao na posicao 3
    });

    path4.setOnAction(e -> {
      animation(window, scene3, scene2,  reset, xwing_view, mf_view, layout3, inferior_esquerda, pathTransition,
      inferior_direita, pathTransition2, back,  sliderMF, sliderX); //incia a animacao na posicao 4
    });

    window.show(); //mostra a tela ao usuario
    window.setResizable(false);// impede o usuario de redimensionar a janela
  }

  /***************************************************************
   * Metodo: animation
   * Funcao: Posiciona as naves no lugar do botao pressionado
   * Parametros:
   * - stage: Tela atual do programa
   * - scene: Proxima cena
   * - button e button2: botao de reset e botao de volta
   * - xwing: imageview de uma das naves
   * - mf: imageview da outra nave
   * - layout: layout em que todos os elementos estao inseridos
   * - path e path 2: caminho de animacao de cada nave
   * - pathTansition e pathTransition2: "controlador" de animacao de cada nave
   * - slider e slider2: Sliders para controle de velocidade
   * Retorno: void
   ******************************************************************/
  private void animation(Stage stage, Scene scene, Scene scene2, Button button, ImageView xwing, ImageView mf, AnchorPane layout, Path path, PathTransition pathTransition,
  Path path2, PathTransition pathTransition2, Button button2, Slider slider, Slider slider2)
  {
      stage.setScene(scene); //muda a cena quando pressionar o botao

      pathTransition.setDuration(Duration.seconds(10)); //define a duracao da animacao
      pathTransition.setPath(path); //define o caminho que a animacao vai percorrer
      pathTransition.setNode(mf); //define o obejto controlado pela animacao
      pathTransition.setCycleCount(Timeline.INDEFINITE); //define quantas vezes o ciclo se repete
      pathTransition.setInterpolator(Interpolator.LINEAR); //adiciona um interpolator linear
      pathTransition.play(); //roda a animacao

      slider.valueProperty().addListener(new ChangeListener<Number>()
      {
        @Override
        public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
          double t1 = newValue.doubleValue(); //cria uma variavel que recebe o valor do slider
          double duration = (1 / t1) * 50; //recalcula a velocidade da animacao e guarda em uma variavel
          //termina a rotina de acoes depois de ter regulado a velocidade

          pathTransition.stop(); //para a animacao antiga

          
          if(t1 == 0)
          {
            pathTransition.setDuration(Duration.seconds(0));
            pathTransition.stop();
          }
          //condicao de parada
          
          pathTransition.setDuration(Duration.seconds(duration)); //define a duracao da animacao
          pathTransition.setPath(path); //define o caminho que a animacao vai percorrer
          pathTransition.setNode(mf); //define o obejto controlado pela animacao
          pathTransition.setCycleCount(Timeline.INDEFINITE); //define quantas vezes o ciclo se repete
          pathTransition.setInterpolator(Interpolator.LINEAR); //adiciona um interpolator linear
          pathTransition.play(); //roda a animacao
          //termina de definir a rotina de acoes depois de ter regulado a velocidade
        }
      });
      //faz o slider controlar a duracao da animacao (sua velocidade)

      pathTransition2.setDuration(Duration.seconds(10)); //define a duracao da animacao
      pathTransition2.setPath(path2); //define o caminho que a animacao vai percorrer
      pathTransition2.setNode(xwing); //define o obejto controlado pela animacao
      pathTransition2.setCycleCount(Timeline.INDEFINITE); //define quantas vezes o ciclo se repete
      pathTransition2.setInterpolator(Interpolator.LINEAR); //adiciona um interpolator linear
      pathTransition2.play(); //roda a animacao

      slider2.valueProperty().addListener(new ChangeListener<Number>()
      {
        @Override
        public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
          double t2 = newValue.doubleValue(); //cria uma variavel que recebe o valor do slider
          double duration2 = (1 / t2) * 50; //recalcula a velocidade da animacao e guarda em uma variavel

          pathTransition2.stop(); //para a animacao antiga

          if(t2 == 0)
          {
            pathTransition2.setDuration(Duration.seconds(0));
            pathTransition2.stop();
          }
          //condicao de parada
          
          pathTransition2.setDuration(Duration.seconds(duration2)); //define a duracao da animacao
          pathTransition2.setPath(path2); //define o caminho que a animacao vai percorrer
          pathTransition2.setNode(xwing); //define o obejto controlado pela animacao
          pathTransition2.setCycleCount(Timeline.INDEFINITE); //define quantas vezes o ciclo se repete
          pathTransition2.setInterpolator(Interpolator.LINEAR); //adiciona um interpolator linear
          pathTransition2.play(); //roda a animacao
          //termina de definir a rotina de acoes depois de ter regulado a velocidade
        }
      });
      //faz o slider controlar a duracao da animacao (sua velocidade)

    button.setOnAction(e -> {

      slider.setValue(0); //zera o valor do slider
      slider2.setValue(0); //zera o valor do slider

      pathTransition.stop(); //para a animacao
      pathTransition2.stop(); //para a animacao

      pathTransition.setDuration(Duration.seconds(10)); //define a duracao da animacao
      pathTransition.setPath(path); //define o caminho que a animacao vai percorrer
      pathTransition.setNode(mf); //define o obejto controlado pela animacao
      pathTransition.setCycleCount(Timeline.INDEFINITE); //define quantas vezes o ciclo se repete
      pathTransition.setInterpolator(Interpolator.LINEAR); //adiciona um interpolator linear
      pathTransition.play(); //roda a animacao

      pathTransition2.setDuration(Duration.seconds(10)); //define a duracao da animacao
      pathTransition2.setPath(path2); //define o caminho que a animacao vai percorrer
      pathTransition2.setNode(xwing); //define o obejto controlado pela animacao
      pathTransition2.setCycleCount(Timeline.INDEFINITE); //define quantas vezes o ciclo se repete
      pathTransition2.setInterpolator(Interpolator.LINEAR); //adiciona um interpolator linear
      pathTransition2.play(); //roda a animacao
    }); //define a rotina de acoes do botao reset

    button2.setOnAction(e -> {
      stage.setScene(scene2); //muda a cena quando pressionar o botao

      slider.setValue(0); //zera o slider da milenium falcon
      slider2.setValue(0); //zera o slider da xwing

      pathTransition.stop(); //para a animacao da millenium falcon
      pathTransition2.stop(); //para a animacao da xwing
    }); //define a rotina de acoes do botao de volta
  }

  /***************************************************************
   * Metodo: inferiorEsquerda
   * Funcao: Cria a rota de animacao da posicao inferior esquerda
   * Parametros:
   *  - Vazio
   * Retorno: Path
   ******************************************************************/

  private Path inferiorEsquerda()
  {
    Path inf_esq = new Path(); //cria uma variavel para armazenar o caminho

    inf_esq.getElements().add(new MoveTo(150.0*0.83, 775.0*0.83));
    inf_esq.getElements().add(new LineTo(150.0*0.83, 700.0*0.83));
    inf_esq.getElements().add(new MoveTo(150.0*0.83, 700.0*0.83));
    inf_esq.getElements().add(new LineTo(350.0*0.83, 625.0*0.83));
    inf_esq.getElements().add(new MoveTo(350.0*0.83, 625.0*0.83));
    inf_esq.getElements().add(new LineTo(350.0*0.83, 575.0*0.83));
    inf_esq.getElements().add(new MoveTo(350.0*0.83, 575.0*0.83));
    inf_esq.getElements().add(new LineTo(200.0*0.83, 450.0*0.83));
    inf_esq.getElements().add(new MoveTo(200.0*0.83, 450.0*0.83));
    inf_esq.getElements().add(new LineTo(200.0*0.83, 300.0*0.83));
    inf_esq.getElements().add(new MoveTo(200.0*0.83, 300.0*0.83));
    inf_esq.getElements().add(new LineTo(350.0*0.83, 250.0*0.83));
    inf_esq.getElements().add(new MoveTo(350.0*0.83, 250.0*0.83));
    inf_esq.getElements().add(new LineTo(350.0*0.83, 160.0*0.83));
    inf_esq.getElements().add(new MoveTo(350.0*0.83, 160.0*0.83));
    inf_esq.getElements().add(new LineTo(200.0*0.83, 100.0*0.83));
    inf_esq.getElements().add(new MoveTo(200.0*0.83, 100.0*0.83));
    inf_esq.getElements().add(new LineTo(200.0*0.83, 0.0*0.83));
    //realiza uma animacao de movimento

    return inf_esq; //retorna o caminho
  }

    /***************************************************************
   * Metodo: inferiorEsquerda
   * Funcao: Cria a rota de animacao da posicao inferior esquerda
   * Parametros:
   *  - Vazio
   * Retorno: Path
   ******************************************************************/

  private Path superiorEsquerda()
  {
    Path sup_esq = new Path(); //cria uma variavel para armazenar o caminho

    sup_esq.getElements().add(new MoveTo(200.0*0.83, 0.0*0.83));
    sup_esq.getElements().add(new LineTo(200.0*0.83, 100.0*0.83));
    sup_esq.getElements().add(new MoveTo(200.0*0.83, 100.0*0.83));
    sup_esq.getElements().add(new LineTo(350.0*0.83, 160.0*0.83));
    sup_esq.getElements().add(new MoveTo(350.0*0.83, 160.0*0.83));
    sup_esq.getElements().add(new LineTo(350.0*0.83, 250.0*0.83));
    sup_esq.getElements().add(new MoveTo(350.0*0.83, 250.0*0.83));
    sup_esq.getElements().add(new LineTo(200.0*0.83, 300.0*0.83));
    sup_esq.getElements().add(new MoveTo(200.0*0.83, 300.0*0.83));
    sup_esq.getElements().add(new LineTo(200.0*0.83, 450.0*0.83));
    sup_esq.getElements().add(new MoveTo(200.0*0.83, 450.0*0.83));
    sup_esq.getElements().add(new LineTo(350.0*0.83, 575.0*0.83));
    sup_esq.getElements().add(new MoveTo(350.0*0.83, 575.0*0.83));
    sup_esq.getElements().add(new LineTo(350.0*0.83, 625.0*0.83));
    sup_esq.getElements().add(new MoveTo(350.0*0.83, 625.0*0.83));
    sup_esq.getElements().add(new LineTo(150.0*0.83, 700.0*0.83));
    sup_esq.getElements().add(new MoveTo(150.0*0.83, 700.0*0.83));
    sup_esq.getElements().add(new LineTo(150.0*0.83, 775.0*0.83));
    //realiza uma animacao de movimento

    return sup_esq; //retorna o caminho
  }

  /***************************************************************
   * Metodo: inferiorEsquerda
   * Funcao: Cria a rota de animacao da posicao inferior esquerda
   * Parametros:
   *  - Vazio
   * Retorno: Path
   ******************************************************************/

  private Path inferiorDireita()
  {
    Path inf_dir = new Path(); //cria uma variavel para armazenar o caminho

    inf_dir.getElements().add(new MoveTo(550.0*0.83, 775.0*0.83));
    inf_dir.getElements().add(new LineTo(550.0*0.83, 700.0*0.83));
    inf_dir.getElements().add(new MoveTo(550.0*0.83, 700.0*0.83));
    inf_dir.getElements().add(new LineTo(350.0*0.83, 625.0*0.83));
    inf_dir.getElements().add(new MoveTo(350.0*0.83, 625.0*0.83));
    inf_dir.getElements().add(new LineTo(350.0*0.83, 575.0*0.83));
    inf_dir.getElements().add(new MoveTo(350.0*0.83, 575.0*0.83));
    inf_dir.getElements().add(new LineTo(500.0*0.83, 450.0*0.83));
    inf_dir.getElements().add(new MoveTo(500.0*0.83, 450.0*0.83));
    inf_dir.getElements().add(new LineTo(500.0*0.83, 300.0*0.83));
    inf_dir.getElements().add(new MoveTo(500.0*0.83, 300.0*0.83));
    inf_dir.getElements().add(new LineTo(350.0*0.83, 250.0*0.83));
    inf_dir.getElements().add(new MoveTo(350.0*0.83, 250.0*0.83));
    inf_dir.getElements().add(new LineTo(350.0*0.83, 160.0*0.83));
    inf_dir.getElements().add(new MoveTo(350.0*0.83, 160.0*0.83));
    inf_dir.getElements().add(new LineTo(500.0*0.83, 100.0*0.83));
    inf_dir.getElements().add(new MoveTo(500.0*0.83, 100.0*0.83));
    inf_dir.getElements().add(new LineTo(500.0*0.83, 0.0*0.83));
    // realiza uma animacao de movimento

    return inf_dir; //retorna o caminho
  }

  /***************************************************************
   * Metodo: inferiorEsquerda
   * Funcao: Cria a rota de animacao da posicao inferior esquerda
   * Parametros:
   *  - Vazio
   * Retorno: Path
   ******************************************************************/

  private Path superiorDireita()
  {
    Path sup_dir = new Path(); //cria uma variavel para armazenar o caminho

    sup_dir.getElements().add(new MoveTo(500.0*0.83, 0.0*0.83));
    sup_dir.getElements().add(new LineTo(500.0*0.83, 100.0*0.83));
    sup_dir.getElements().add(new MoveTo(500.0*0.83, 100.0*0.83));
    sup_dir.getElements().add(new LineTo(350.0*0.83, 160.0*0.83));
    sup_dir.getElements().add(new MoveTo(350.0*0.83, 160.0*0.83));
    sup_dir.getElements().add(new LineTo(350.0*0.83, 250.0*0.83));
    sup_dir.getElements().add(new MoveTo(350.0*0.83, 250.0*0.83));
    sup_dir.getElements().add(new LineTo(500.0*0.83, 300.0*0.83));
    sup_dir.getElements().add(new MoveTo(500.0*0.83, 300.0*0.83));
    sup_dir.getElements().add(new LineTo(500.0*0.83, 450.0*0.83));
    sup_dir.getElements().add(new MoveTo(500.0*0.83, 450.0*0.83));
    sup_dir.getElements().add(new LineTo(350.0*0.83, 575.0*0.83));
    sup_dir.getElements().add(new MoveTo(350.0*0.83, 575.0*0.83));
    sup_dir.getElements().add(new LineTo(350.0*0.83, 625.0*0.83));
    sup_dir.getElements().add(new MoveTo(350.0*0.83, 625.0*0.83));
    sup_dir.getElements().add(new LineTo(550.0*0.83, 700.0*0.83));
    sup_dir.getElements().add(new MoveTo(550.0*0.83, 700.0*0.83));
    sup_dir.getElements().add(new LineTo(550.0*0.83, 775.0*0.83));
    //realiza uma animacao de movimento

    return sup_dir; //retorna o caminho
  }
}