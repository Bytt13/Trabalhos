/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 01/07/2024
* Ultima alteracao.: 01/07/2024
* Nome.............: ControllerCidade
* Funcao...........: Administra a parte funcional do programa, ou seja, a parte do transito autonomo de fato
****************************************************************/
package Controller;

import java.util.concurrent.Semaphore;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import Models.CarroAmarelo;
import Models.CarroAzul;
import Models.CarroCiano;
import Models.CarroBranco;
import Models.CarroLaranja;
import Models.CarroPrata;
import Models.CarroVermelho;
import Models.CarroRoxo;

//fim das bibliotecas importadas

public class ControllerCidade implements Initializable{

  Stage stage; //cria uma variavel stage
  Scene scene; //cria uma variavel de cena
  Parent root; //cria uma variavel root, que no futuro carregara nosso arquivo FXML
  CarroAmarelo c1; //cria uma variavel thread que controla o carro amarelo
  CarroAzul c2; //cria uma variavel para thread que controla o carro azul
  CarroCiano c3; //cria uma variavel para thread que controla o carro ciano
  CarroBranco c4; //cria uma variavel para thread que controla o carro branco
  CarroPrata c5; //cria uma variavel para thread que controla o carro prata
  CarroVermelho c6; //cria uma variavel para thread que controla o carro vermelho
  CarroLaranja c7; //cria uma variavel para thread que controla o carro laranja
  CarroRoxo c8; //cria uma variavel para thread que controla o carro roxo
  public static volatile boolean isRunning; //cria uma variavel que controla o while de todas as threads


  @FXML
  private Button voltar;
  @FXML
  private Button reset;
  @FXML
  private Button rotaRoxoButton;
  @FXML
  private Button rotaPrataButton;
  @FXML
  private Button rotaVermelhoButton;
  @FXML
  private Button rotaLaranjaButton;
  @FXML
  private Button rotaBrancoButton;
  @FXML
  private Button rotaAmareloButton;
  @FXML
  private Button rotaCianoButton;
  @FXML
  private Button rotaAzulButton;
  @FXML
  private ImageView carroAmarelo;
  @FXML
  private ImageView carroAzul;
  @FXML
  private ImageView carroCiano;
  @FXML
  private ImageView carroPrata;
  @FXML
  private ImageView carroLaranja;
  @FXML
  private ImageView carroVermelho;
  @FXML
  private ImageView carroRoxo;
  @FXML
  private ImageView carroBranco;
  @FXML
  private ImageView rotaAmarela;
  @FXML
  private ImageView rotaVermelho;
  @FXML
  private ImageView rotaCiano;
  @FXML
  private ImageView rotaRoxo;
  @FXML
  private ImageView rotaLaranja;
  @FXML
  private ImageView rotaBranca;
  @FXML
  private ImageView rotaAzul;
  @FXML
  private ImageView rotaPrata;
  @FXML
  private Button pausaAmarelo, pausaVermelho, pausaAzul, pausaCiano, pausaLaranja, pausaPrata, pausaBranco, pausaRoxo;
  @FXML
  private Slider sliderLaranja, sliderCiano, sliderAzul, sliderVermelho, sliderAmarelo, sliderRoxo, sliderPrata, sliderBranco;
  //fim da declaracao de objetos que vamos utilizar do arquivo FXML

  public static volatile Semaphore h19;
  public static volatile Semaphore v26v27h5h4;
  public static volatile Semaphore v4v5h26h27;
  public static volatile Semaphore v15;
  public static volatile Semaphore h23;
  public static volatile Semaphore h15;
  public static volatile Semaphore h16;
  public static volatile Semaphore v3;
  public static volatile Semaphore h12v12;
  public static volatile Semaphore h14;
  public static volatile Semaphore v16;
  public static volatile Semaphore v19;
  public static volatile Semaphore v20;
  public static volatile Semaphore h3;
  public static volatile Semaphore h25;
  public static volatile Semaphore v28;
  public static volatile Semaphore v24;
  public static volatile Semaphore h24;
  public static volatile Semaphore h29;
  public static volatile Semaphore v23;
  public static volatile Semaphore h28;
  public static volatile Semaphore v13;
  public static volatile Semaphore v14;
  public static volatile Semaphore v7;
  public static volatile Semaphore v1v2h1h2;
  public static volatile Semaphore v18;
  //fim da criacao dos semaforos necessarios

/****************************************************************
 * Metodo: initialize
 * Funcao: e o metodo que inicializa todo o processo de controller do fxml
 * Parametros: URL location, ResourceBundle resources
 * Retorno: void
 ****************************************************************/  
  @Override
  public void initialize(URL location, ResourceBundle resources){
    

    c1 = new CarroAmarelo(this, carroAmarelo, sliderAmarelo); //constroi a thread passando o controller, carro e o slider como parametro
    c2 = new CarroAzul(this, carroAzul, sliderAzul); //constroi a thread passando o controller, carro e o slider como parametro
    c3 = new CarroCiano(this, carroCiano, sliderCiano); //constroi a thread passando o controller, carro e o slider como parametro
    c4 = new CarroBranco(this, carroBranco, sliderBranco); //constroi a thread passando o controller, carro e o slider como parametro
    c5 = new CarroPrata(this, carroPrata, sliderPrata); //constroi a thread passando o controller, carro e o slider como parametro
    c6 = new CarroVermelho(this, carroVermelho, sliderVermelho); //constroi a thread passando o controller, carro e o slider como parametro
    c7 = new CarroLaranja(this, carroLaranja, sliderLaranja); //constroi a thread passando o controller, carro e o slider como parametro
    c8 = new CarroRoxo(this, carroRoxo, sliderRoxo); //constroi a thread passando o controller, carro e o slider como parametro

    pontoInicial(); //chama a funcao pontoInicial
    

    c1.start(); //inicia a thread do carro 1
    c2.start(); //inicia a thread do carro 2
    c3.start(); //inicia a thread do carro 3
    c4.start(); //inicia a thread do carro 4
    c5.start(); //inicia a thread do carro 5
    c6.start(); //inicia a thread do carro 6
    c7.start(); //inica a thread do carro 7 
    c8.start(); //inicia a thread do carro 8
  }
  /****************************************************************
   * Metodo: pontoInicial
   * Funcao: configura tudo para seu ponto inicial, sendo util para o botao voltar e reset
   * Parametros: nenhum
   * Retorno: void
   ****************************************************************/
  public void pontoInicial(){

    h19 = new Semaphore(1);
    v26v27h5h4 = new Semaphore(1);
    v4v5h26h27 = new Semaphore(1);
    v15 = new Semaphore(1);
    h23 = new Semaphore(1);
    h15 = new Semaphore(1);
    h16 = new Semaphore(1);
    v3 = new Semaphore(1);
    h12v12 = new Semaphore(1);
    h14 = new Semaphore(1);
    v16 = new Semaphore(1);
    v19 = new Semaphore(1);
    v20 = new Semaphore(1);
    h3 = new Semaphore(1);
    h25 = new Semaphore(1);
    v28 = new Semaphore(1);
    v24 = new Semaphore(1);
    h24 = new Semaphore(1);
    h29 = new Semaphore(1);
    v23 = new Semaphore(1);
    h28 = new Semaphore(1);
    v13 = new Semaphore(1);
    v1v2h1h2 = new Semaphore(1);
    v7 = new Semaphore(1);
    v18 = new Semaphore(1);
    v14 = new Semaphore(1);

    //fim da inicializacao dos semaforos
    
    isRunning = true;

    rotaAmarela.setVisible(false);
    rotaCiano.setVisible(false);
    rotaAzul.setVisible(false);
    rotaPrata.setVisible(false);
    rotaLaranja.setVisible(false);
    rotaVermelho.setVisible(false);
    rotaRoxo.setVisible(false);
    rotaBranca.setVisible(false);
    //define a visibilidade como falsa de todas as rotas

    carroAmarelo.setLayoutX(864);
    carroAmarelo.setLayoutY(444);
    //define a posicao inicial do carro amarelo

    carroAzul.setLayoutX(-14);
    carroAzul.setLayoutY(444);
    //define a posicao inicial do carro azul

    carroCiano.setLayoutX(864);
    carroCiano.setLayoutY(364);
    //define a posicao inicial do carro ciano

    carroBranco.setLayoutX(864);
    carroBranco.setLayoutY(144);
    //define a posicao inicial do carro branco

    carroVermelho.setLayoutX(838);
    carroVermelho.setLayoutY(-40);
    //define a posicao inicial do carro vermelho

    carroPrata.setLayoutX(709);
    carroPrata.setLayoutY(420);
    //define a posicao inicial do carro prata

    carroRoxo.setLayoutX(314);
    carroRoxo.setLayoutY(420);
    //define a posicao inicial do carro roxo

    carroLaranja.setLayoutX(-14);
    carroLaranja.setLayoutY(243);
    //define a posicao inicial do carro laranja
  }

/****************************************************************
 * Metodo: voltar
 * Funcao: define o que acontece quando o botao de voltar e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void voltar(ActionEvent e) throws IOException{
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaInicio.fxml")); //cria um loader que carrega a proxima cena
    root =  loader.load(); //define o root que armazena esse loader
    scene = new Scene(root); //faz com que exista uma cena que tenha esse root
    stage = (Stage) voltar.getScene().getWindow(); //faz a janela pegar a cena que o botao iniciar esta
    stage.setScene(scene); //troca a cena pela do root
    stage.show(); //mostra a janela, ja com a cena trocada, na tela do usuario
    isRunning = false;
  }
/****************************************************************
 * Metodo: resetar
 * Funcao: define o que acontece quando o botao de reset e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void resetar(ActionEvent e) throws IOException{
    isRunning = false;
    pontoInicial();
    System.out.println(h19);
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Cidade.fxml")); //cria um loader que carrega a proxima cena
    root =  loader.load(); //define o root que armazena esse loader
    scene = new Scene(root); //faz com que exista uma cena que tenha esse root
    stage = (Stage) voltar.getScene().getWindow(); //faz a janela pegar a cena que o botao iniciar esta
    stage.setScene(scene); //troca a cena pela do root
    stage.show(); //mostra a janela, ja com a cena trocada, na tela do usuario
  }
/****************************************************************
 * Metodo: rotaAmareloButton
 * Funcao: define o que acontece quando o botao de rota amarela e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void rotaAmareloButton(ActionEvent e) throws IOException{
    checarRota(rotaAmarela);
  }
/****************************************************************
 * Metodo: rotaPrataButton
 * Funcao: define o que acontece quando o botao de rota prata e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void rotaPrataButton(ActionEvent e) throws IOException{
    checarRota(rotaPrata);
  }
/****************************************************************
 * Metodo: rotaCianoButton
 * Funcao: define o que acontece quando o botao de rota ciano e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void rotaCianoButton(ActionEvent e) throws IOException{
    checarRota(rotaCiano);
  }
/****************************************************************
 * Metodo: rotaAzulButton
 * Funcao: define o que acontece quando o botao de rota azul e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void rotaAzulButton(ActionEvent e) throws IOException{
    checarRota(rotaAzul);
  }
/****************************************************************
 * Metodo: rotaVermelhoButton
 * Funcao: define o que acontece quando o botao de rota vermelha e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void rotaVermelhoButton(ActionEvent e) throws IOException{
    checarRota(rotaVermelho);
  }
/****************************************************************
 * Metodo: rotaBrancoButton
 * Funcao: define o que acontece quando o botao de rota branca e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
@FXML
private void rotaBrancoButton(ActionEvent e) throws IOException{
  checarRota(rotaBranca);
}
/****************************************************************
 * Metodo: rotaLaranjaButton
 * Funcao: define o que acontece quando o botao de rota laranja e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
@FXML
private void rotaLaranjaButton(ActionEvent e) throws IOException{
  checarRota(rotaLaranja);
}
/****************************************************************
 * Metodo: rotaRoxoButton
 * Funcao: define o que acontece quando o botao de rota roxa e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
@FXML
private void rotaRoxoButton(ActionEvent e) throws IOException{
  checarRota(rotaRoxo);
}
  /****************************************************************
   * Metodo: checarRota
   * Funcao: checa se a rota ja esta visivel ou nao
   * Parametros: ImageView rota
   * Retorno: void
   ****************************************************************/
  private void checarRota(ImageView rota){
    if(rota.isVisible() == true){
      rota.setVisible(false); //define a visibilidade como falsa
    }
    //condicao que analisa se a rota ja esta visivel
    else {
      rota.setVisible(true); //define a visibilidade como verdadeira
    }
    //condicao que roda o codigo caso a rota nao esteja visivel
  }

/****************************************************************
 * Metodo: getVelSlider
 * Funcao: captura o valor atual do slider referido ao slider passado como parametro
 * Parametros: Slider
 * Retorno: velocity
 ****************************************************************/
public int getVelSlider(Slider slider){
  double value = slider.getValue();
  int velocity = (int) value;
  return velocity;
  //pega o valor do slider do guts e transforma num inteiro para ser usado pelo codigo
}
/****************************************************************
 * Metodo: pausarRoxo
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarRoxo(ActionEvent e) throws IOException{
    if(sliderRoxo.getValue() != 20){
      sliderRoxo.setValue(20);
    }
    else{
      sliderRoxo.setValue(10);
    }
    //muda o valor do slider
  }
/****************************************************************
 * Metodo: pausarCiano
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarCiano(ActionEvent e) throws IOException{
    if(sliderCiano.getValue() != 20){
      sliderCiano.setValue(20);
    }
    else{
      sliderCiano.setValue(10);
    }
    //muda o valor do slider
  }
/****************************************************************
 * Metodo: pausarAmarelo
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarAmarelo(ActionEvent e) throws IOException{
    if(sliderAmarelo.getValue() != 20){
      sliderAmarelo.setValue(20);
    }
    else{
      sliderAmarelo.setValue(10);
    }
    //muda o valor do slider
  }
/****************************************************************
 * Metodo: pausarLaranja
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarLaranja(ActionEvent e) throws IOException{
    if(sliderLaranja.getValue() != 20){
      sliderLaranja.setValue(20);
    }
    else{
      sliderLaranja.setValue(10);
    }
    //muda o valor do slider
  }
/****************************************************************
 * Metodo: pausarAzul
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarAzul(ActionEvent e) throws IOException{
    if(sliderAzul.getValue() != 20){
      sliderAzul.setValue(20);
    }
    else{
      sliderAzul.setValue(10);
    }
    //muda o valor do slider
  }
/****************************************************************
 * Metodo: pausarVermelho
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarVermelho(ActionEvent e) throws IOException{
    if(sliderVermelho.getValue() != 20){
      sliderVermelho.setValue(20);
    }
    else{
      sliderVermelho.setValue(10);
    }
    //muda o valor do slider
  }
/****************************************************************
 * Metodo: pausarPrata
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarPrata(ActionEvent e) throws IOException{
    if(sliderPrata.getValue() != 20){
      sliderPrata.setValue(20);
    }
    else{
      sliderPrata.setValue(10);
    }
    //muda o valor do slider
  }
/****************************************************************
 * Metodo: pausarBranco
 * Funcao: define o que acontece quando o botao de pause e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void pausarBranco(ActionEvent e) throws IOException{
    if(sliderBranco.getValue() != 20){
      sliderBranco.setValue(20);
    }
    else{
      sliderBranco.setValue(10);
    }
    //muda o valor do slider
  }
}