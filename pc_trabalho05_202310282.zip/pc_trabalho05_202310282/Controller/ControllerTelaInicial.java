/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 01/07/2024
* Ultima alteracao.: 01/07/2024
* Nome.............: ControllerTelaInicial
* Funcao...........: Administra a parte inicial do programa, no caso, a primeira tela
****************************************************************/
package Controller;

import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
//import Controller.ControllerCidade;
//fim da importacao das bibliotecas que vamos utilizar

public class ControllerTelaInicial implements Initializable {

Stage stage; //cria uma variavel stage
Scene scene; //cria uma variavel de cena
Parent root; //cria uma variavel Parent, que carregara nosso arquivo FXML no futuro

@FXML
private Button iniciar; //adiciona o botao iniciar

/****************************************************************
 * Metodo: initialize
 * Funcao: e o metodo que inicializa todo o processo de controller do fxml
 * Parametros: URL location, ResourceBundle resources
 * Retorno: void
 ****************************************************************/

 @Override
 public void initialize(URL location, ResourceBundle resources){

 }

/****************************************************************
 * Metodo: iniciarGTM
 * Funcao: e o metodo que define o que acontece quando o botao de iniciar o programa e apertado
 * Parametros: ActionEvent event
 * Retorno: void
 ****************************************************************/
@FXML
private void iniciar(ActionEvent e) throws IOException{
  FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Cidade.fxml")); //cria um loader que carrega a proxima cena
  root =  loader.load(); //define o root que armazena esse loader
  scene = new Scene(root); //faz com que exista uma cena que tenha esse root
  stage = (Stage) iniciar.getScene().getWindow(); //faz a janela pegar a cena que o botao iniciar esta
  stage.setScene(scene); //troca a cena pela do root
  stage.show(); //mostra a janela, ja com a cena trocada, na tela do usuario
}
}