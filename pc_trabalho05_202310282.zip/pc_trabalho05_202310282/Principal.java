/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 01/07/2024
* Ultima alteracao.: 01/07/2024
* Nome.............: Principal
* Funcao...........: Iniciar e executar o programa como um todo
****************************************************************/

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import Controller.ControllerTelaInicial;
import Controller.ControllerCidade;
//fim das bibliotecas importadas

public class Principal extends Application{
/****************************************************************
 * Metodo: main
 * Funcao: inicializa o programa e permite que o javafx seja iniciado
 * Parametros: String[] args
 * Retorno: void
 ****************************************************************/
  public static void main(String[] args){
    launch(args);
  }

/****************************************************************
 * Metodo: start
 * Funcao: da start na tela que desencadeia todo o programa
 * Parametros: Stage window
 * Retorno: void
 ****************************************************************/
@Override
  public void start(Stage window) throws Exception{
    Image icon = new Image("Images/Inicio/Icon.jpg"); //define a imagem do icone
    Parent root = FXMLLoader.load(getClass().getResource("/View/TelaInicio.fxml")); //cria um root que carrega um arquivo FXML
    Scene telaInicial = new Scene(root); //diz que a cena da tela inicial e o root criado acima

    window.setTitle("GTM"); //define o titulo da janela
    window.setScene(telaInicial); //define a cena da janela
    window.getIcons().add(icon); //adiciona o icone na janela
    window.setResizable(false); //define que o redimensionamento da janela e falso, ou seja, a janela possui um tamanho fixo
    window.show(); //mostra a janela na tela do usuario
    window.setOnCloseRequest(e -> {System.exit(0);}); //encerra o programa corretamente, garantido que as threads parem de funcionar
  }
}