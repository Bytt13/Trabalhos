/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/07/2024
* Ultima alteracao.: --/07/2024
* Nome.............: Carros
* Funcao...........: Essa classe controla por meio de threads os carros
****************************************************************/
package Models;

import Controller.ControllerCidade;
import javafx.application.Platform;
import javafx.scene.image.ImageView;
import javafx.scene.control.Slider;

public class CarroPrata extends Thread {
  private ControllerCidade controller;
  private ImageView carroPrata;
  private int posY;
  private int posX;
  private Slider sliderPrata;
  private boolean complicacao = true;

  /****************************************************************
   * Metodo: Construtor
   * Funcao: Constroi o objeto com os parametros passados
   * Parametros: ControllerCidade controller ImageView carroPrata Slider sliderPrata
   * Retorno: Nenhum
   ****************************************************************/
  public CarroPrata(ControllerCidade controller, ImageView carroPrata, Slider sliderPrata) {
    this.controller = controller;
    this.carroPrata = carroPrata;
    this.sliderPrata = sliderPrata;
  }

  /****************************************************************
   * Metodo: run
   * Funcao: roda a thread que faz os carros andarem
   * Parametros: Nenhum
   * Retorno: void
   ****************************************************************/
  public void run() {
    try {
      while (ControllerCidade.isRunning) {
       caminhoPrata(carroPrata); //faz o caminho do carro prata
      } //fim do while true
    } catch (Exception e) {
      e.printStackTrace();
    } //fim do try catch
  }
  // fim do while que roda a thread infinitamente

  /****************************************************************
   * Metodo: up
   * Funcao: anima o carro para andar para cima
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void up(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderPrata)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setY(posY--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try catch
    }
    //fim do for
  }

  /****************************************************************
   * Metodo: left
   * Funcao: anima o carro para andar para esquerda
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void left(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderPrata)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setX(posX--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try-catch
    } //fim do for
  }

  /****************************************************************
   * Metodo: down
   * Funcao: anima o carro para andar para baixo
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void down(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderPrata)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setY(posY++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
      } //fim do try-catch
    } //fim do for

  /****************************************************************
   * Metodo: right
   * Funcao: anima o carro para andar para direita
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void right(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderPrata)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setX(posX++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
        //fim do try-catch
      }
      //fim do for
    } 
    
  /****************************************************************
   * Metodo: caminhoPrata
   * Funcao: anima o carro para andar sua rota
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void caminhoPrata(ImageView carro)  throws InterruptedException {
    if(complicacao){

      complicacao = false;
    }
    ControllerCidade.v13.release();
    up(carro,39);
    ControllerCidade.h29.release();
    ControllerCidade.h24.acquire();
    ControllerCidade.v24.acquire(); 
    up(carro,30);
    up(carro,73);
    ControllerCidade.h24.release();
    ControllerCidade.v23.acquire(); 
    up(carro,60);
    up(carro,68);
    up(carro,78);
    ControllerCidade.v24.release();
    ControllerCidade.v23.release();
    up(carro,60);
    up(carro,20);
    ControllerCidade.v26v27h5h4.acquire();
    up(carro,20);
    carro.setRotate(-90);
    left(carro,98);
    ControllerCidade.h3.acquire();
    left(carro,90);
    left(carro,110);
    ControllerCidade.v26v27h5h4.release();
    ControllerCidade.h12v12.acquire();
    left(carro,100);
    carro.setRotate(180);
    down(carro,30);
    ControllerCidade.h3.release();
    ControllerCidade.v13.acquire();
    down(carro,20);
    down(carro,138);
    ControllerCidade.h28.acquire();
    ControllerCidade.v20.acquire();
    down(carro,48);
    ControllerCidade.h12v12.release();
    down(carro,50);
    down(carro,73);
    ControllerCidade.v15.acquire();
    down(carro,60);
    down(carro,49);
    down(carro,15);
    carro.setRotate(90);
    right(carro,112);
    ControllerCidade.v15.release();
    ControllerCidade.h29.acquire(); 
    right(carro,100);
    right(carro,98);
    ControllerCidade.h28.release();
    ControllerCidade.v20.release();
    right(carro,90);
    carro.setRotate(0);
    up(carro,34);
    left(carro,1);
    //termina o caminho do carro prata
  }
   /****************************************************************
   * Metodo: pause
   * Funcao: para o carro
   * Parametros: nenhum
   * Retorno: void
   ****************************************************************/
  public void pause(){
    if(sliderPrata.getValue() == 20){
      while(sliderPrata.getValue() == 20){
        try{
          Thread.sleep(10); //faz a thread ficar dormindo enquanto o valor do slider for 20
        } catch (Exception e) {
          e.printStackTrace();
        } //fim do try catch
      } //fim do while que bota a thread pra dormir
    } // fim da checagem se o slider esta ou nao a velocidade desejada para rodar o metodo
  }
}