/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/07/2024
* Ultima alteracao.: --/07/2024
* Nome.............: Carros
* Funcao...........: Essa classe controla por meio de threads os carros
****************************************************************/
package Models;

import Controller.ControllerCidade;
import javafx.application.Platform;
import javafx.scene.image.ImageView;
import javafx.scene.control.Slider;

public class CarroAzul extends Thread {
  private ControllerCidade controller;
  private ImageView carroAzul;
  private int posY;
  private int posX;
  private Slider sliderAzul;
  private boolean complicacao = true;

  /****************************************************************
   * Metodo: Construtor
   * Funcao: Constroi o objeto com os parametros passados
   * Parametros: ControllerCidade controller ImageView carroAzul, Slider sliderAzul
   * Retorno: Nenhum
   ****************************************************************/
  public CarroAzul(ControllerCidade controller, ImageView carroAzul, Slider sliderAzul) {
    this.controller = controller;
    this.carroAzul = carroAzul;
    this.sliderAzul = sliderAzul;
  }

  /****************************************************************
   * Metodo: run
   * Funcao: roda a thread que faz os carros andarem
   * Parametros: Nenhum
   * Retorno: void
   ****************************************************************/
  public void run() {
    try {
      while (ControllerCidade.isRunning) {
       caminhoAzul(carroAzul); //faz o caminho do carro azul
      } //fim do while true
    } catch (Exception e) {
      e.printStackTrace();
    } //fim do try catch
  }
  // fim do while que roda a thread infinitamente

  /****************************************************************
   * Metodo: up
   * Funcao: anima o carro para andar para cima
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void up(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderAzul)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setY(posY--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try catch
    }
    //fim do for
  }

  /****************************************************************
   * Metodo: left
   * Funcao: anima o carro para andar para esquerda
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void left(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderAzul)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setX(posX--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try-catch
    } //fim do for
  }

  /****************************************************************
   * Metodo: down
   * Funcao: anima o carro para andar para baixo
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void down(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderAzul)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setY(posY++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
      } //fim do try-catch
    } //fim do for

  /****************************************************************
   * Metodo: right
   * Funcao: anima o carro para andar para direita
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void right(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderAzul)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setX(posX++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
        //fim do try-catch
      }
      //fim do for
    } 
  /****************************************************************
   * Metodo: caminhoAzul
   * Funcao: anima o carro para andar sua rota
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void caminhoAzul(ImageView carro) throws InterruptedException{
    if(complicacao){

      complicacao = false;
    }
    up(carro,69);
    up(carro,113);
    up(carro,98);
    up(carro,138);
    up(carro,40);
    carro.setRotate(90);
    right(carro,153);
    right(carro,164);
    right(carro,212);
    right(carro,188);
    right(carro,158);
    carro.setRotate(180);
    down(carro,50);
    down(carro,138);
    down(carro,98);
    down(carro,113);
    down(carro,79);
    carro.setRotate(-90);
    left(carro,162);
    left(carro,188);
    carro.setRotate(0);
    up(carro,69);
    up(carro,113);
    up(carro,118);
    carro.setRotate(-90);
    left(carro,208);
    carro.setRotate(180);
    down(carro,118);
    down(carro,113);
    down(carro,69);
    carro.setRotate(-90);
    left(carro,164);
    left(carro,153);
    carro.setRotate(0);
    up(carro,19);
    //termina o caminho do carro azul
  }
   /****************************************************************
   * Metodo: pause
   * Funcao: para o carro
   * Parametros: nenhum
   * Retorno: void
   ****************************************************************/
  public void pause(){
    if(sliderAzul.getValue() == 20){
      while(sliderAzul.getValue() == 20){
        try{
          Thread.sleep(10); //faz a thread ficar dormindo enquanto o valor do slider for 20
        } catch (Exception e) {
          e.printStackTrace();
        } //fim do try catch
      } //fim do while que bota a thread pra dormir
    } // fim da checagem se o slider esta ou nao a velocidade desejada para rodar o metodo
  }
}