/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/07/2024
* Ultima alteracao.: --/07/2024
* Nome.............: Carros
* Funcao...........: Essa classe controla por meio de threads os carros
****************************************************************/
package Models;

import Controller.ControllerCidade;
import javafx.application.Platform;
import javafx.scene.image.ImageView;
import javafx.scene.control.Slider;

public class CarroVermelho extends Thread {
  private ControllerCidade controller;
  private ImageView carroVermelho;
  private int posY;
  private int posX;
  private Slider sliderVermelho;
  private boolean complicacao = true;

  /****************************************************************
   * Metodo: Construtor
   * Funcao: Constroi o objeto com os parametros passados
   * Parametros: ControllerCidade controller ImageView carroVermelho Slider sliderVermelho
   * Retorno: Nenhum
   ****************************************************************/
  public CarroVermelho(ControllerCidade controller, ImageView carroVermelho, Slider sliderVermelho) {
    this.controller = controller;
    this.carroVermelho = carroVermelho;
    this.sliderVermelho = sliderVermelho;
  }

  /****************************************************************
   * Metodo: run
   * Funcao: roda a thread que faz os carros andarem
   * Parametros: Nenhum
   * Retorno: void
   ****************************************************************/
  public void run() {
    try {
      while (ControllerCidade.isRunning) {
       caminhoVermelho(carroVermelho); //faz o caminho do carro Vermelho
      } //fim do while true
    } catch (Exception e) {
      e.printStackTrace();
    } //fim do try catch
  }
  // fim do while que roda a thread infinitamente

  /****************************************************************
   * Metodo: up
   * Funcao: anima o carro para andar para cima
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void up(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderVermelho)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setY(posY--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try catch
    }
    //fim do for
  }

  /****************************************************************
   * Metodo: left
   * Funcao: anima o carro para andar para esquerda
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void left(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderVermelho)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setX(posX--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try-catch
    } //fim do for
  }

  /****************************************************************
   * Metodo: down
   * Funcao: anima o carro para andar para baixo
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void down(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderVermelho)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setY(posY++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
      } //fim do try-catch
    } //fim do for

  /****************************************************************
   * Metodo: right
   * Funcao: anima o carro para andar para direita
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void right(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderVermelho)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setX(posX++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
        //fim do try-catch
      }
      //fim do for
    } 
  /****************************************************************
   * Metodo: caminhoVermelho
   * Funcao: anima o carro para andar sua rota
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void caminhoVermelho(ImageView carro) throws InterruptedException{
    if(complicacao){
      ControllerCidade.v26v27h5h4.acquire();
      complicacao = false;
    }
    left(carro,162);
    left(carro,58);
    ControllerCidade.v16.acquire();
    left(carro,100);
    carro.setRotate(180);
    down(carro,55);
    ControllerCidade.v26v27h5h4.release();
    down(carro,40);
    carro.setRotate(-90);
    left(carro,102);
    ControllerCidade.v16.release();
    ControllerCidade.h12v12.acquire();
    ControllerCidade.v7.acquire();
    left(carro,100);
    carro.setRotate(180);
    down(carro,98);
    carro.setRotate(-90);
    left(carro,174);
    carro.setRotate(180);
    down(carro,48);
    ControllerCidade.h12v12.release();
    ControllerCidade.h16.acquire();
    down(carro,50);
    carro.setRotate(-90);
    left(carro,73);
    ControllerCidade.v7.release();
    ControllerCidade.v4v5h26h27.acquire();
    left(carro,80);
    carro.setRotate(180);
    down(carro,73);
    ControllerCidade.h16.release();
    down(carro,40);
    down(carro,79);
    carro.setRotate(90);
    right(carro,158);
    right(carro,84);
    ControllerCidade.v15.acquire();
    right(carro,80);
    carro.setRotate(0);
    up(carro,39);
    ControllerCidade.v4v5h26h27.release();
    ControllerCidade.h23.acquire();
    up(carro,30);
    carro.setRotate(90);
    right(carro,112);
    ControllerCidade.v15.release();
    ControllerCidade.h19.acquire();
    ControllerCidade.v19.acquire();
    right(carro,100);
    carro.setRotate(0);
    up(carro,73);
    ControllerCidade.h23.release();
    up(carro,40);
    carro.setRotate(90); 
    right(carro,100);
    ControllerCidade.v19.release();
    ControllerCidade.v23.acquire();
    right(carro,88);
    carro.setRotate(0);
    up(carro,48);
    ControllerCidade.h19.release();
    ControllerCidade.h15.acquire();
    up(carro,50);
    carro.setRotate(90);
    right(carro,82);
    ControllerCidade.v23.release();
    ControllerCidade.v26v27h5h4.acquire();
    right(carro,80);
    carro.setRotate(0);
    up(carro,118);
    ControllerCidade.h15.release();
    up(carro,85);
    carro.setRotate(-90);
    left(carro,33);
    //termina o caminho do carro vermelho
  }
   /****************************************************************
   * Metodo: pause
   * Funcao: para o carro
   * Parametros: nenhum
   * Retorno: void
   ****************************************************************/
  public void pause(){
    if(sliderVermelho.getValue() == 20){
      while(sliderVermelho.getValue() == 20){
        try{
          Thread.sleep(10); //faz a thread ficar dormindo enquanto o valor do slider for 20
        } catch (Exception e) {
          e.printStackTrace();
        } //fim do try catch
      } //fim do while que bota a thread pra dormir
    } // fim da checagem se o slider esta ou nao a velocidade desejada para rodar o metodo
  }

  public void resetarposicao(){
    Platform.runLater(() -> {
      carroVermelho.setLayoutX(838);
      carroVermelho.setLayoutY(-40);
    });
  }
}