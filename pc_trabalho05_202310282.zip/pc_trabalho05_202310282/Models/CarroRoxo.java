/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/07/2024
* Ultima alteracao.: --/07/2024
* Nome.............: Carros
* Funcao...........: Essa classe controla por meio de threads os carros
****************************************************************/
package Models;

import Controller.ControllerCidade;
import javafx.application.Platform;
import javafx.scene.image.ImageView;
import javafx.scene.control.Slider;

public class CarroRoxo extends Thread {
  private ControllerCidade controller;
  private ImageView carroRoxo;
  private int posY;
  private int posX;
  private Slider sliderRoxo;
  private boolean complicacao = true;

  /****************************************************************
   * Metodo: Construtor
   * Funcao: Constroi o objeto com os parametros passados
   * Parametros: ControllerCidade controller ImageView carroRoxo Slider sliderRoxo
   * Retorno: Nenhum
   ****************************************************************/
  public CarroRoxo(ControllerCidade controller, ImageView carroRoxo, Slider sliderRoxo) {
    this.controller = controller;
    this.carroRoxo = carroRoxo;
    this.sliderRoxo = sliderRoxo;
  }

  /****************************************************************
   * Metodo: run
   * Funcao: roda a thread que faz os carros andarem
   * Parametros: Nenhum
   * Retorno: void
   ****************************************************************/
  public void run() {
    try {
      while (ControllerCidade.isRunning) {
       caminhoRoxo(carroRoxo); //faz o caminho do carro roxo
      } //fim do while true
    } catch (Exception e) {
      e.printStackTrace();
    } //fim do try catch
  }
  // fim do while que roda a thread infinitamente

  /****************************************************************
   * Metodo: up
   * Funcao: anima o carro para andar para cima
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void up(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderRoxo)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setY(posY--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try catch
    }
    //fim do for
  }

  /****************************************************************
   * Metodo: left
   * Funcao: anima o carro para andar para esquerda
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void left(ImageView carro, double pixels) {
    for (int i = 0; i <= pixels; i++) {
      try {
        pause();
        Thread.sleep(controller.getVelSlider(sliderRoxo)); //dorme a thread pelo tempo definido pelo slider
        Platform.runLater(() -> {
          carro.setX(posX--); //atualiza a posicao do carro
        });
      } catch (Exception e) {
        e.printStackTrace();
      } //fim do try-catch
    } //fim do for
  }

  /****************************************************************
   * Metodo: down
   * Funcao: anima o carro para andar para baixo
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void down(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderRoxo)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setY(posY++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
      } //fim do try-catch
    } //fim do for

  /****************************************************************
   * Metodo: right
   * Funcao: anima o carro para andar para direita
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
    public void right(ImageView carro, double pixels) {
      for (int i = 0; i <= pixels; i++) {
        try {
          pause();
          Thread.sleep(controller.getVelSlider(sliderRoxo)); //dorme a thread pelo tempo definido pelo slider
          Platform.runLater(() -> {
            carro.setX(posX++); //atualiza a posicao do carro
          });
        } catch (Exception e) {
          e.printStackTrace();
        }
        //fim do try-catch
      }
      //fim do for
    } 

  /****************************************************************
   * Metodo: caminhoRoxo
   * Funcao: anima o carro para andar sua rota
   * Parametros: ImageView carro
   * Retorno: void
   ****************************************************************/
  public void caminhoRoxo(ImageView carro) throws InterruptedException{
    if(complicacao){
      ControllerCidade.v15.acquire();
      complicacao = false;
    }
    up(carro,69);
    ControllerCidade.h28.release();
    up(carro,53);
    ControllerCidade.v15.release();
    up(carro,50);
    carro.setRotate(-90);
    left(carro,84);
    ControllerCidade.h16.acquire();
    left(carro, 80);
    left(carro,103);
    ControllerCidade.v3.acquire();
    ControllerCidade.v13.release();
    ControllerCidade.h3.acquire();
    ControllerCidade.h12v12.acquire();
    left(carro,50);
    carro.setRotate(0);
    up(carro,48);
    ControllerCidade.h16.release();
    up(carro,50);
    carro.setRotate(90);
    right(carro,83);
    ControllerCidade.v3.release();
    right(carro,70);
    right(carro,84);
    right(carro,80);
    carro.setRotate(0);
    up(carro,138);
    up(carro,5);
    ControllerCidade.h12v12.release();
    up(carro,45);
    carro.setRotate(90);
    right(carro,112);
    ControllerCidade.v16.acquire();
    right(carro,100);
    carro.setRotate(180);
    down(carro,40);
    ControllerCidade.h3.release();
    ControllerCidade.h14.acquire();
    down(carro,10);
    down(carro,78);
    ControllerCidade.v16.release();
    ControllerCidade.v28.acquire();
    down(carro,60);
    carro.setRotate(90);
    right(carro,108);
    ControllerCidade.h15.acquire();
    right(carro,80);
    ControllerCidade.h14.release(); 
    right(carro,82);
    right(carro,80);
    carro.setRotate(180);
    down(carro,48);
    ControllerCidade.h15.release();
    down(carro,50);
    carro.setRotate(-90);
    left(carro,82);
    ControllerCidade.v28.release();
    ControllerCidade.h19.acquire();
    left(carro,80);
    left(carro,109);
    ControllerCidade.v19.acquire();
    left(carro,80);
    carro.setRotate(180);
    down(carro,63);
    ControllerCidade.h19.release();
    ControllerCidade.v20.acquire();
    down(carro,50);
    down(carro,49);
    ControllerCidade.h28.acquire();
    ControllerCidade.v13.acquire();
    ControllerCidade.v19.release();
    down(carro,30);
    carro.setRotate(-90);
    left(carro,112);
    ControllerCidade.v20.release();
    ControllerCidade.v15.acquire();
    left(carro,97);
    carro.setRotate(0);
    up(carro,18);
    //termina o caminho do carro roxo
  }
   /****************************************************************
   * Metodo: pause
   * Funcao: para o carro
   * Parametros: nenhum
   * Retorno: void
   ****************************************************************/
  public void pause(){
    if(sliderRoxo.getValue() == 20){
      while(sliderRoxo.getValue() == 20){
        try{
          Thread.sleep(10); //faz a thread ficar dormindo enquanto o valor do slider for 20
        } catch (Exception e) {
          e.printStackTrace();
        } //fim do try catch
      } //fim do while que bota a thread pra dormir
    } // fim da checagem se o slider esta ou nao a velocidade desejada para rodar o metodo
  }
}