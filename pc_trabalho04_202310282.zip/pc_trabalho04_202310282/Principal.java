/* ***************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/06/2024
* Ultima alteracao.: 13/06/2024
* Nome.............: Principal
* Funcao...........: Essa classe e a responsavel por iniciar corretamente o programa, e chamar todas as outras classes para funcionar
****************************************************************/
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import Controller.ControllerCombat;
import Controller.ControllerAboutProject;
import Controller.ControllerPrincipal;
//fim da importacao de bibliotecas que vamos utilizar

public class Principal extends Application{

/****************************************************************
 * Metodo: main
 * Funcao: inicializa o programa e permite que o javafx seja iniciado
 * Parametros: String[] args
 * Retorno: void
 ****************************************************************/
  public static void main(String[] args){
    launch(args); 
  }

/****************************************************************
 * Metodo: start
 * Funcao: da start na tela que desencadeia todo o programa
 * Parametros: Stage window
 * Retorno: voidSwsw
 ****************************************************************/
  @Override
  public void start(Stage window) throws Exception{
    Image icon = new Image("Images/icon.jpg"); //cria o icone da janela como um objeto da classe Image
    Parent root = FXMLLoader.load(getClass().getResource("/View/TelaInicial.fxml")); //cria um root, para a cena carregar e exibir
    Scene scene = new Scene(root); //cria uma cena, que recebe como parametro o root criado acima

    window.setTitle("Berserk"); //define o titulo da janela
    window.setScene(scene); //define a cena que a janela vai apresentar
    window.getIcons().add(icon); //adiciona o icone na parte superior da janela
    window.setResizable(false); //define que o redimensionamento de tamanho da janela e falso, ou seja, possui um tamanho fixo
    window.show(); //mostra a janela no monitor
    window.setOnCloseRequest(e -> {System.exit(0);}); //garante que o programa seja parado corretamente quando fechar a janela
  }
}