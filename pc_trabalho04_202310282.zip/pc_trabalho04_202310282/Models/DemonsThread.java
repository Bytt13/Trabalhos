/* ***************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/06/2024
* Ultima alteracao.: 13/06/2024
* Nome.............: DemonsThread
* Funcao...........: Essa classe controla por meio de threads os proprios inimigos
*************************************************************** */
package Models;

import Controller.ControllerCombat;
//fim da importacao das bibliotecas que vamos utilizar

public class DemonsThread extends Thread{

  private ControllerCombat controller; //cria o controller
  
/****************************************************************
 * Metodo: Construtor
 * Funcao: Constroi o objeto com os parametros passados
 * Parametros: ControllerCombat controller
 * Retorno: Nenhum
 ****************************************************************/
  public DemonsThread(ControllerCombat controller){
    this.controller = controller;
  }

/****************************************************************
 * Metodo: run
 * Funcao: inicializa a thread
 * Parametros: Nenhum
 * Retorno: void
 ****************************************************************/
  public void run(){
    try{
      ControllerCombat.mutex.acquire(); //prende o mutex
      if(ControllerCombat.queue < ControllerCombat.spaces){
        ControllerCombat.queue++; //fila aumenta em 1
        onSpace(); //chama o metodo onSpace para ocupar o espaco
        ControllerCombat.enemies.release(); //solta os inimigos
        ControllerCombat.mutex.release(); //solta o mutex
        ControllerCombat.guts.acquire(); //prende o guts
        sleep(10); //faz a thread dormir por 10ms
        freeSpace(); //chama o metodo freeSpace para liberar espaco
      } else {
        ControllerCombat.mutex.release(); //solta o mutex
        full();//chama o metodo full para identificar se esta cheio o local
      } //fim da identificacao de comparacao entre espacos disponiveis e fila
    } catch (Exception exception) {
      exception.printStackTrace();
    } //fim do catch
  }

/****************************************************************
 * Metodo: onSpace
 * Funcao: coloca os demonios nos lugares
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
  private void onSpace(){
    if(!controller.getDemon2().isVisible()){
      controller.getDemon2().setVisible(true); //define o demonio 2 como visivel
    } //fim da identificacao para ver se o demonio 2 esta visivel
    else if(!controller.getDemon3().isVisible()){
      controller.getDemon3().setVisible(true); //define o demonio 3 como visivel
    } //fim da identificacao para ver se o demonio 3 esta visivel
    else if(!controller.getDemon4().isVisible()){
      controller.getDemon4().setVisible(true); //define o demonio 4 como visivel
    } //fim da identificacao para ver se o demonio 4 esta visivel
    else if(!controller.getDemon5().isVisible()){
      controller.getDemon5().setVisible(true); //define o demonio 5 como visivel
    } //fim da identificacao para ver se o demonio 5 esta visivel
    else if(!controller.getDemon6().isVisible()){
      controller.getDemon6().setVisible(true); //define o demonio 6 como visivel
    } //fim da identificacao para ver se o demonio 6 esta visivel
  }

/****************************************************************
 * Metodo: freeSpace
 * Funcao: libera o espaco dos demonios para novos chegarem
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
  private void freeSpace(){
    if(controller.getVelGuts() == 3000){
      while(controller.getVelGuts() == 3000){
        try{
          sleep(1);
        } catch (Exception exception) {
          exception.printStackTrace();
        }
      }
    }
    if(controller.getDemon6().isVisible()){
      controller.getDemon6().setVisible(false); //define o demonio 6 como invisivel
    } //fim da identificacao para ver se o demonio 6 e visivel
    else if(controller.getDemon5().isVisible()){
      controller.getDemon5().setVisible(false); //define o demonio 5 como invisivel
    } //fim da identificacao para ver se o demonio 6 e visivel
    else if(controller.getDemon4().isVisible()){
      controller.getDemon4().setVisible(false); //define o demonio 4 como invisivel
    } //fim da identificacao para ver se o demonio 6 e visivel
    else if(controller.getDemon3().isVisible()){
      controller.getDemon3().setVisible(false); //define o demonio 3 como invisivel
    } //fim da identificacao para ver se o demonio 6 e visivel
    else if(controller.getDemon2().isVisible()){
      controller.getDemon2().setVisible(false); //define o demonio 2 como invisivel
    } //fim da identificacao para ver se o demonio 6 e visivel
    controller.attack(); //chama o metodo attack do controller
  }

/****************************************************************
 * Metodo: full
 * Funcao: define o que acontece quando o espaco ja esta cheio (5 demonios na fila, e 1 sendo morto pelo guts)
 * Parametros: ControllerCombat controller
 * Retorno: void
 ****************************************************************/
  private void full(){
    if(controller.getDemon6().isVisible()){
      while(controller.getDemon1().isVisible()){
        try{
          sleep(1); //faz a thread dormir por 1ms
        } catch (Exception exception) {
          exception.printStackTrace();
        } //fim do catch
      } //fim da condicao de demonio visivel
    } //fim da identificacao de demonio visivel
  }

/****************************************************************
 * Metodo: getController
 * Funcao: da o get do controller
 * Parametros: nenhum
 * Retorno: controller
 ****************************************************************/
  public ControllerCombat getController(){
    return controller;
  }

  /****************************************************************
 * Metodo: setController
 * Funcao: seta o controller
 * Parametros: ControllerCombat controller
 * Retorno: void
 ****************************************************************/
  public void setController(ControllerCombat controller){
    this.controller = controller;
  }
}