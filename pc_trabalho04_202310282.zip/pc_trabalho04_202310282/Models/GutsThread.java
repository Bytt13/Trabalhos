/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/06/2024
* Ultima alteracao.: --/06/2024
* Nome.............: GutsThread
* Funcao...........: Essa classe controla por meio de threads o personagem principal, nosso guerreiro Guts
****************************************************************/
package Models;

import Controller.ControllerCombat;
//fim da importacao das bibliotecas que vamos utilizar

public class GutsThread extends Thread{

  private ControllerCombat controller;

/****************************************************************
 * Metodo: Construtor
 * Funcao: Constroi o objeto com os parametros passados
 * Parametros: ControllerCombat controller
 * Retorno: Nenhum
 ****************************************************************/

public GutsThread(ControllerCombat controller){
  this.controller = controller;
}

 

public void run(){
  while(ControllerCombat.bool == true){
    try{
      if(ControllerCombat.queue == 0){
        controller.rest(); //chama a funcao de rest
      } //fim da identificacao do numero de demonios na fila
      sleep(controller.getVelArrive()); //faz a thread dormir pelo tempo definido no slider
      ControllerCombat.enemies.acquire(); //o semaforo prende os inimigos
      ControllerCombat.mutex.acquire(); //o mutex esta preso
      ControllerCombat.queue--; //a fila diminui
      ControllerCombat.guts.release(); //o guts e solto
      ControllerCombat.mutex.release(); //o mutex e solto

      attack(); //chama a funcao attack
    } catch (Exception exception) {
      exception.printStackTrace();
    } //fim do catch
  } //fim do loop infinito
}

/****************************************************************
 * Metodo: attack
 * Funcao: define o ataque do guts
 * Parametros: Nenhum
 * Retorno: void
 ****************************************************************/
private void attack(){
  boolean check = false; //cria um boolean para checagem de condicao
  while(!check){
    if(controller.getVelGuts() == 3000){
      while(controller.getVelGuts() == 3000){
        try{
          sleep(1); //faz a thread dormir por 1 ms
        } catch (Exception exception) {
          exception.printStackTrace();
        } //fim do catch
      } //fim da condicao de valor do sliderx
    } //fim da identificacao do valor do slider
    if(controller.getDemon1().isVisible()){
      controller.attack();//chama a funcao attack do controller
      try {
        sleep(controller.getVelGuts()); //faz a thread dormir pelo tempo proposto no slider
      } catch (Exception exception){
        exception.printStackTrace();
      } //fim do catch
    } //fim da identificacao de demonio
    controller.kill(); //chama a funcao kill do controller
    try{
      sleep(controller.getVelGuts());
    } catch(Exception exception) {
      exception.printStackTrace();
    } //fim do catch
    check = true; //define a checagem como verdadeiro
  } //fim da identificacao da variavel boolean de checagem
}

/****************************************************************
 * Metodo: setController
 * Funcao: seta o controller
 * Parametros: ControllerCombat controller
 * Retorno: void
 ****************************************************************/

public void setController(ControllerCombat controller){
  this.controller = controller;
}

/****************************************************************
 * Metodo: getController
 * Funcao: da o get do controller
 * Parametros: Nenhum
 * Retorno: controller
 ****************************************************************/
public ControllerCombat getController(){
  return controller;
}
}