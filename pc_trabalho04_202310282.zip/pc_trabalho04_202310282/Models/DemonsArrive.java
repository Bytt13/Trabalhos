/* ***************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/06/2024
* Ultima alteracao.: --/06/2024
* Nome.............: DemonsArrive
* Funcao...........: Essa classe controla por meio de threads a chegada de inimigos (demonios) no eclipse
*************************************************************** */
package Models;

import Controller.ControllerCombat;
//fim da importacao das bibliotecas que vamos utilizar

public class DemonsArrive extends Thread{

  private ControllerCombat controller;

/****************************************************************
 * Metodo: Construtor
 * Funcao: Constroi o objeto com os parametros passados
 * Parametros: ControllerCombat controller
 * Retorno: Nenhum
 ****************************************************************/

public DemonsArrive(ControllerCombat controller){
  this.controller = controller;
}

/****************************************************************
 * Metodo: run
 * Funcao: inicializa a thread
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
public void run(){
  while(ControllerCombat.bool = true){
      if(controller.getVelArrive() == 3000){
          while(controller.getVelArrive() == 3000){
            try{
              sleep(1); //faz a thread dormir enquanto o valor do slider for igual ao passado acima
            } catch (Exception exception) {
              exception.printStackTrace();
            } //fim do catch
          } //fim da condicao do valor do slider
      } //fim da identificacao do valor do slider
      
      DemonsThread demonsThread = new DemonsThread(controller); //cria a thread
      demonsThread.start(); //roda a thread

      try{
        Thread.sleep(controller.getVelArrive()); //faz a thread dormir pelo tempo indicado pelo slider
      } catch (Exception exception) {
        exception.printStackTrace();
      }
  } //fim do loop infinito
}

}