/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/06/2024
* Ultima alteracao.: 13/06/2024
* Nome.............: ControllerPrincipal
* Funcao...........: Administra a parte inicial do programa, no caso, a primeira tela
****************************************************************/
package Controller;

import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
//fim da importacao das bibliotecas que vamos utilizar[]

public class ControllerPrincipal implements Initializable{
  Stage stage; //cria um stage para ser mostrado
  Scene scene; //cria uma cena para o stage apresentar
  Parent root; //cria um root para ser carregado pela cena

  @FXML
  private Button startEclipse; //cria o botao de iniciar o programa
  @FXML
  private Button aboutProject; //cria o botao que leva para a tela de "sobre o projeto"

/****************************************************************
 * Metodo: initialize
 * Funcao: e o metodo que inicializa todo o processo de controller do fxml
 * Parametros: URL location, ResourceBundle resources
 * Retorno: void
 ****************************************************************/
  @Override
  public void initialize(URL location, ResourceBundle resources){

  }
  @FXML
  private void startEclipse(ActionEvent e) throws IOException{
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Combat.fxml")); //cria um loader para carregar a pagina de combate
    root = loader.load(); //faz o root receber esse loader
    scene = new Scene(root); //a cena agora carrega a pagina de combate gracas ao root e ao loader
    stage = (Stage) startEclipse.getScene().getWindow(); //faz o stage receber o stage que o botao esta localizado
    stage.setScene(scene); //define a cena do botao como a de combate, gerando assim uma troca de tela
    ControllerCombat.bool = true;
    stage.show(); //mostra o stage (a janela)
  }

/****************************************************************
 * Metodo: aboutProject
 * Funcao: e o metodo que define o que acontece quando o botao de sobre o projeto e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  private void aboutProject(ActionEvent e) throws IOException{
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/AboutProject.fxml")); //cria um loader para carregar a pagina de sobre o projeto
    root = loader.load(); //faz o root receber esse loader
    scene = new Scene(root); //a cena agora carrega a pagina de sobre o projeto gracas ao root e ao loader
    stage = (Stage) aboutProject.getScene().getWindow(); //faz o stage receber o stage que o botao esta localizado
    stage.setScene(scene); //define a cena do botao como a tela de sobre o projeto gerando assim uma troca de tela
    stage.show(); //mostra o stage (a janela)
  }
}