/* ***************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/06/2024
* Ultima alteracao.: 13/06/2024
* Nome.............: ControllerCombat
* Funcao...........: Adminsitra a principal parte do projeto, a cena de combate, em que o programa do barbeiro sera simulado com todas as suas funcoes
****************************************************************/
package Controller;

import java.util.concurrent.Semaphore;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import Models.GutsThread;
import Models.DemonsArrive;
//fim da importacao das bibliotecas que vamos utilizar

public class ControllerCombat implements Initializable{
  Stage stage; //cria um stage para mostrar a tela de combate
  Scene scene; //cria uma cena que sera apresentada pelo stage
  Parent root; //cria um root que sera carregado pela cena
  GutsThread gutsThread; //cria um objeto da thread do guts
  DemonsArrive arrivingThread; //cria um objeto da thread da chegada de demonios

  @FXML
  private Button reset; //cria um botao de reset
  @FXML
  private Button back; //cria um botao de volta
  @FXML
  private Slider sliderGuts; //cria um slider para velocidade do guts
  @FXML
  private Slider sliderEnemy; //cria um slider para velocidade de geracao de inimigos
  @FXML
  private ImageView gutsSleep; //cria uma imageview para o guts quando esta descansando
  @FXML
  private ImageView gutsAttacking; //cria uma imageview para a animacao do ataque do guts
  @FXML
  private ImageView demon1; //cria uma imageview para o primeiro tipo de demonio
  @FXML
  private ImageView demon2; //cria uma imageview para o segundo tipo de demonio
  @FXML
  private ImageView demon3; //cria uma imageview para o terceiro tipo de demonio
  @FXML
  private ImageView demon4; //cria uma imageview para o quarto tipo de demonio
  @FXML
  private ImageView demon5; //cria uma imageview para o quinto tipo de demonio
  @FXML
  private ImageView demon6; //cria uma imageview para o sexto tipo de demonio
  @FXML
  private ImageView transforming; //cria uma imageview para a animacao de transformacao do guts em berserk
  @FXML
  private ImageView berserkAttacking; //cria uma imageview para a animacao do guts em modo berserk atacando
  @FXML
  private ImageView enemyDeath; //cria uma imageview para a morte dos inimigos

  public static int queue;
  public static final int spaces = 5;
  public static Semaphore guts;
  public static Semaphore mutex;
  public static Semaphore enemies;
  public static boolean bool = true;

/****************************************************************
 * Metodo: initialize
 * Funcao: e o metodo que inicializa todo o processo de controller do fxml
 * Parametros: URL location, ResourceBundle resources
 * Retorno: void
 ****************************************************************/  
  @Override
  public void initialize(URL location, ResourceBundle resources){

    gutsSleep.setVisible(true);
    gutsSleep.setLayoutX(131);
    gutsSleep.setLayoutY(307);
    //deixa a animacao do guts dormindo visivel, e define as coordenadas dela

    gutsAttacking.setVisible(false);
    gutsAttacking.setLayoutX(158);
    gutsAttacking.setLayoutY(215);
    //deixa a animacao do guts atacando invisivel e define as coordenadas dela

    transforming.setVisible(false);
    transforming.setLayoutX(158);
    transforming.setLayoutY(215);
    //deixa a animacao do guts se transformando invisivel e define as coordenadas dela

    berserkAttacking.setVisible(false);
    berserkAttacking.setLayoutX(158);
    berserkAttacking.setLayoutY(215);
    //deixa a animacao do guts(berserker) atacando invisivel e define as coordenadas dela

    demon1.setVisible(false);
    demon1.setLayoutX(311);
    demon1.setLayoutY(302);
    //deixa o demonio visivel e define as coordenadas dele

    demon2.setVisible(true);
    demon2.setLayoutX(569);
    demon2.setLayoutY(302);
    //deixa o demonio visivel e define as coordenadas dele

    demon3.setVisible(true);
    demon3.setLayoutX(480);
    demon3.setLayoutY(297);
    //deixa o demonio visivel e define as coordenadas dele

    demon4.setVisible(true);
    demon4.setLayoutX(613);
    demon4.setLayoutY(286);
    //deixa o demonio visivel e define as coordenadas dele

    demon5.setVisible(true);
    demon5.setLayoutX(554);
    demon5.setLayoutY(278);
    //deixa o demonio visivel e define as coordenadas dele

    demon6.setVisible(true);
    demon6.setLayoutX(400);
    demon6.setLayoutY(278);
    // deixa o demonio visivel e define as coordenadas dele

    enemyDeath.setVisible(false);
    enemyDeath.setLayoutX(400);
    enemyDeath.setLayoutY(620);
    //deixa a animacao de morte do demonio invisivel e define as coordenadas dela

    gutsThread = new GutsThread(this); //inicializa as variaveis de thread criadas la em cima
    arrivingThread = new DemonsArrive(this); //inicializa as variaveis de thread criadas la em cima

    mutex = new Semaphore(1); //cria os semaforos para utilizarmos no codigo das threads
    guts = new Semaphore(0); //cria os semaforos para utilizarmos no codigo das threads
    enemies = new Semaphore(0); //cria os semaforos para utilizarmos no codigo das threads

    gutsThread.start(); //inicia a thread do guts
    arrivingThread.start(); //inicia a thread da chegada de inimigos

  }

/****************************************************************
 * Metodo: rest
 * Funcao: define o que acontece quando nao existem demonios para o guts enfrentar
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
  public void rest(){
    gutsAttacking.setVisible(false);
    berserkAttacking.setVisible(false);
    transforming.setVisible(false);
    gutsSleep.setVisible(true);
    demon1.setVisible(false);
    demon2.setVisible(false);
    demon3.setVisible(false);
    demon4.setVisible(false);
    demon5.setVisible(false);
    demon6.setVisible(false);
    enemyDeath.setVisible(false);
    //define que o guts vai parar de atacar e comecar a dormir
  }
/****************************************************************
 * Metodo: kill
 * Funcao: define o que acontece quando guts mata um demonio
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
  public void kill(){
    demon1.setVisible(false);
    enemyDeath.setVisible(true);
    
    //ativa a animacao de inimigo derrotado

  }
/****************************************************************
 * Metodo: berserkTransformation
 * Funcao: define o que acontece quando guts fica em velocidade maxima
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
  public void berserkTransformation(){
    gutsAttacking.setVisible(false);
    gutsSleep.setVisible(false);
    berserkAttacking.setVisible(false);
    transforming.setVisible(true);
    enemyDeath.setVisible(false);
    //substitui o guts normal pela transformacao da armadura berserker
  }
/****************************************************************
 * Metodo: berserker
 * Funcao: define o que acontece quando o guts esta em modo berserker
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
  public void berserker(){
    gutsSleep.setVisible(false);
    gutsAttacking.setVisible(false);
    transforming.setVisible(false);
    berserkAttacking.setVisible(true);
    enemyDeath.setVisible(false);
    //define o guts como totalmente transformado pela armadura e atacando
  }
/****************************************************************
 * Metodo: attacking
 * Funcao: define o que acontece quando guts enfrenta um demonio
 * Parametros: nenhum
 * Retorno: void
 ****************************************************************/
public void attack(){
  gutsSleep.setVisible(false);
  gutsAttacking.setVisible(true);
  transforming.setVisible(false);
  berserkAttacking.setVisible(false);
  demon1.setVisible(true);
  enemyDeath.setVisible(false);
  //define o que e visivel e o que nao e visivel no metodo attack
}

/****************************************************************
 * Metodo: reset
 * Funcao: define o que acontece quando o botao de reset e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  public void reset(ActionEvent e) throws IOException{
    sliderGuts.setValue(50); //define os valores do slider do guts para 50
    sliderEnemy.setValue(50); //define os valores do slider dos inimigos para 50
    ControllerCombat.queue = 0; //zera a fila
    rest(); //chama a animacao de descanso
  }

/****************************************************************
 * Metodo: back
 * Funcao: define o que acontece quando o botao de voltar e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  public void back(ActionEvent e) throws IOException{
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaInicial.fxml")); //cria um loader para carregar a pagina inicial
    root = loader.load(); //faz o root receber esse loader
    scene = new Scene(root); //a cena agora carrega a pagina inicial gracas ao root e ao loader
    stage = (Stage) back.getScene().getWindow(); //faz o stage receber o stage que o botao esta localizado
    stage.setScene(scene); //define a cena do botao como a tela inicial, gerando assim uma troca de tela
    sliderEnemy.setValue(50); //define o valor do slider para 50
    sliderGuts.setValue(50); //define o valor do slider para 50
    bool = false;
    stage.show(); //mostra o stage (a janela)
  }

/****************************************************************
 * Metodo: getVelGuts
 * Funcao: captura o valor atual do slider referido ao guts
 * Parametros: nenhum
 * Retorno: velocity
 ****************************************************************/
  public int getVelGuts(){
    double value = sliderGuts.getValue();
    if(value == 0){
      value = 1;
    }
    int velocity = (int) value * 30;
    return velocity;
    //pega o valor do slider do guts e transforma num inteiro para ser usado pelo codigo
  }

/****************************************************************
 * Metodo: getVelArrive
 * Funcao: captura o valor atual do slider refeerido a chegada de demonios
 * Parametros: nenhum
 * Retorno: velocity
 ****************************************************************/
  public int getVelArrive(){
    double value = sliderEnemy.getValue();
    if(value == 0){
      value = 1;
    }
    int velocity = (int) value * 30;
    return velocity;
    //pega o valor do slider de chegada dos demonios e transforma num inteiro para ser usado pelo codigo
  }

/****************************************************************
 * Metodo: getDemon1
 * Funcao: pega o imageview do demon enumerado
 * Parametros: nenhum
 * Retorno: demon1
 ****************************************************************/
  public ImageView getDemon1(){
    return demon1;
  }
/****************************************************************
 * Metodo: getDemon2
 * Funcao: pega o imageview do demon enumerado
 * Parametros: nenhum
 * Retorno: demon2
 ****************************************************************/
  public ImageView getDemon2(){
    return demon2;
  }
/****************************************************************
 * Metodo: getDemon3
 * Funcao: pega o imageview do demon enumerado
 * Parametros: nenhum
 * Retorno: demon3
 ****************************************************************/
  public ImageView getDemon3(){
    return demon3;
  }
 /****************************************************************
 * Metodo: getDemon4
 * Funcao: pega o imageview do demon enumerado
 * Parametros: nenhum
 * Retorno: demon4
 ****************************************************************/
  public ImageView getDemon4(){
    return demon4;
  }
/****************************************************************
 * Metodo: getDemon5
 * Funcao: pega o imageview do demon enumerado
 * Parametros: nenhum
 * Retorno: demon5
 ****************************************************************/
  public ImageView getDemon5(){
    return demon5;
  }
/****************************************************************
 * Metodo: getDemon6
 * Funcao: pega o imageview do demon enumerado
 * Parametros: nenhum
 * Retorno: demon6
 ****************************************************************/
public ImageView getDemon6(){
  return demon6;
}
/****************************************************************
 * Metodo: getGutsAttacking
 * Funcao: pega o imageview do guts atacando
 * Parametros: nenhum
 * Retorno: gutsAttacking
 ****************************************************************/
  public ImageView getGutsAttacking(){
    return gutsAttacking;
  }
/****************************************************************
 * Metodo: getGutsSleep
 * Funcao: pega o imageview do guts quando esta descansando
 * Parametros: nenhum
 * Retorno: gutsSleep
 ****************************************************************/
  public ImageView getGutsSleep(){
    return gutsSleep;
  }
/****************************************************************
 * Metodo: getEnemyDeath
 * Funcao: pega o imageview da morte do inimigo
 * Parametros: nenhum
 * Retorno: enemyDeath
 ****************************************************************/
  public ImageView getEnemyDeath(){
    return enemyDeath;
  }
/****************************************************************
 * Metodo: getBerserkAttacking
 * Funcao: pega o imageview do  guts(berserker) atacando
 * Parametros: nenhum
 * Retorno: berserkAttacking
 ****************************************************************/
  public ImageView getBerserkAttacking(){
    return berserkAttacking;
  }
/****************************************************************
 * Metodo: getTransforming
 * Funcao: pega o imageview do guts se transformando
 * Parametros: nenhum
 * Retorno: transforming
 ****************************************************************/
  public ImageView getTransforming(){
    return transforming;
  }
}