/* ***************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 02/06/2024
* Ultima alteracao.: 11/06/2024
* Nome.............: ControllerAboutProject
* Funcao...........: Administra a parte de "sobre o projeto"
*************************************************************** */
package Controller;

import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
//fim da importacao das bibliotecas que vamos utilizar

public class ControllerAboutProject implements Initializable{
  Stage stage; //cria um stage para mostrar a troca de tela
  Scene scene; //cria uma cena que sera apresentada pelo stage
  Parent root; //cria um root que sera carregado pela cena

  @FXML
  private Button back; //cria um botao para voltar

/****************************************************************
 * Metodo: initialize
 * Funcao: e o metodo que inicializa todo o processo de controller do fxml
 * Parametros: URL location, ResourceBundle resources
 * Retorno: void
 ****************************************************************/
  @Override
  public void initialize(URL location, ResourceBundle resources){

  }

/****************************************************************
 * Metodo: back
 * Funcao: define o que acontece quando o botao de voltar e apertado
 * Parametros: ActionEvent e
 * Retorno: void
 ****************************************************************/
  @FXML
  public void back(ActionEvent e) throws IOException{
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaInicial.fxml")); //cria um loader para carregar a pagina inicial
    root = loader.load(); //faz o root receber esse loader
    scene = new Scene(root); //a cena agora carrega a pagina inicial gracas ao root e ao loader
    stage = (Stage) back.getScene().getWindow(); //faz o stage receber o stage que o botao esta localizado
    stage.setScene(scene); //define a cena do botao como a tela inicial, gerando assim uma troca de tela
    stage.show(); //mostra o stage (a janela)
  }
}