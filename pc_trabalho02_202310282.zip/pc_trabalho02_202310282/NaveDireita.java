/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 05/05/2024
* Ultima alteracao.: 05/05/2024
* Nome.............: Nave Esquerda
* Funcao...........: O programa tem a funcao de simular o andamento e controle de um trem (nave), em diferentes posicoes de inicio.
*                   
****************************************************************/
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.application.Platform;
//fim da listagem de importacoes de bibliotecas utilizadas

public class NaveDireita extends Thread{
  private ImageView image; //cria uma variavel que recebe a imagem da nave esquerda
  private double vel; //cria uma variavel que atribui velocidade a nave esquerda
  private double posY; //posicao inicial Y
  private double posX; //posicao inicial X
  private double pontoParametro = 650.0*0.83;
  private boolean direcao; //direcao que a nave vai seguir
  public Scene scene; //variavel para receber a cena para efetuar a troca de tela
  public Scene scene2; //variavel para receber outra cena para efetuar a troca de tela
  public Stage stage; //variavel para receber o stage para efetuar a troca de tela
  public Slider slider; //variavel para receber o slider para controlar a velocidade
  public Button reset; //variavel para receber o botao de reset
  public Button back; //variavel para receber o botao de voltar
  public boolean swap; //variavel para identificar se o caminho e para cima ou para baixo
  private boolean start = true; //variavel para comecar a thread corretamente 
  
  //criacao de um construtor para nossa thread
  public NaveDireita(ImageView image, double vel, double posX, double posY, boolean direcao, Scene scene, Stage stage, Slider slider,
  Button reset, Button back, Scene scene2, boolean swap){
    this.image = image;
    this.vel = vel;
    this.posX = posX;
    this.posY = posY;
    this.scene = scene;
    this.scene2 = scene2;
    this.stage = stage;
    this.direcao = direcao;
    this.reset = reset;
    this.back = back;
    this.swap = swap;
    this.slider = slider;
    //fim da atribuicao de variaveis ao construtor
  }

  /***************************************************************
   * Metodo: run
   * Funcao: Comeca a thread e faz a nave esquerda se movimentar
   * Parametros:
   * - nenhum
   * Retorno: void
   ******************************************************************/

  public void run(){
    Platform.runLater(() -> {
      image.setLayoutX(posX); //coloca a imagem na posicao inicial X
      image.setLayoutY(posY); //coloca a imagem na posicao inicial Y
      stage.setScene(scene); //muda a cena para a cena dos trilhos
      slider.setValue(10);  //inicia o slider na posicao 10
      start = true; //"inicia" a thread
    });
    //incio de um while que da o movimento a nave
    while(start == true){
      Platform.runLater(() -> {
        slider.valueProperty().addListener(new ChangeListener<Number>()
        {
          @Override
          public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
            double t1 = newValue.doubleValue(); //cria uma variavel que recebe o valor do slider
            double duration = (t1/30); //recalcula a velocidade da animacao e guarda em uma variavel
            vel = duration; //faz a velocidade ser atualizada
            //termina a rotina de acoes depois de ter regulado a velocidade
          }
        });
        //faz o slider controlar a duracao da animacao (sua velocidade)
        reset.setOnAction(e -> {
          image.setLayoutX(posX); //coloca a imagem na posicao inicial X
          image.setLayoutY(posY); //coloca a imagem na posicao inicial Y
          stage.setScene(scene); //muda a cena para a cena dos trilhos
          direcao = true;
          slider.setValue(0); //zera o valor do slider
        });

        if(swap == false){
          if(direcao == true){
            image.setLayoutY(image.getLayoutY() - vel);
            if(image.getLayoutY() <= pontoParametro){
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 125.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 250.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 515.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 700.0 *0.83){
              image.setLayoutY(image.getLayoutY() - vel);
              image.setLayoutY(posY);
              image.setLayoutX(posX);
              direcao = true;
            } //move a nave no eixo Y
          }
          if(direcao == false){
            image.setLayoutY(image.getLayoutY() - vel);
            image.setLayoutX(image.getLayoutX() - vel);
            if(image.getLayoutY() <= pontoParametro - 100.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() <= pontoParametro - 350.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() <= pontoParametro - 500.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() <= pontoParametro - 700.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
          }
        }
        else
        {
        if(direcao == true){
          image.setLayoutY(image.getLayoutY() + vel);
          if(image.getLayoutY() >= pontoParametro - 500){
            direcao = false;
          } //move a nave no eixo Y
          if(image.getLayoutY() >= pontoParametro - 450.0 *0.83){
            image.setLayoutX(image.getLayoutX() + vel);
            direcao = false;
          } //move a nave no eixo Y
          if(image.getLayoutY() >= pontoParametro - 250.0 *0.83){
            image.setLayoutX(image.getLayoutX() - vel);
            direcao = false;
          } //move a nave no eixo Y
          if(image.getLayoutY() >= pontoParametro - 70.0*0.83){
            image.setLayoutX(image.getLayoutX() + vel);
            direcao = false;
          } //move a nave no eixo Y
          if(image.getLayoutY() >= pontoParametro + 120.0 *0.83){
            image.setLayoutY(image.getLayoutY() + vel);
            image.setLayoutY(posY);
            image.setLayoutX(posX);
            direcao = true;
          } //move a nave no eixo Y
        }
        if(direcao == false){
          image.setLayoutY(image.getLayoutY() + vel);
          image.setLayoutX(image.getLayoutX() - vel);
          if(image.getLayoutY() >= pontoParametro - 480.0 *0.83){
            image.setLayoutX(image.getLayoutX() + vel);
            direcao = true;
          } //move a nave no eixo Y e no eixo X
          if(image.getLayoutY() >= pontoParametro - 350.0 *0.83){
            image.setLayoutX(image.getLayoutX() - vel);
            direcao = true;
          } //move a nave no eixo Y e no eixo X
          if(image.getLayoutY() >= pontoParametro - 100.0 *0.83){
            image.setLayoutX(image.getLayoutX() + vel);
            direcao = true;
          } //move a nave no eixo Y e no eixo X
          if(image.getLayoutY() >= pontoParametro + 75.0 *0.83){
            image.setLayoutX(image.getLayoutX() - vel);
            direcao = true;
          } //move a nave no eixo Y e no eixo X
        }
      }
    });

      try{
        Thread.sleep(10); //pausa o funcionamento da thread para fluidez do programa
      }
      catch(InterruptedException e)
      {
      e.printStackTrace();
      }
    }
  }
}
