/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 22/03/2024
* Ultima alteracao.: 05/05/2024
* Nome.............: Principal
* Funcao...........: O programa tem a funcao de simular o andamento e controle simultaneo de 2 trens (naves), em diferentes posicoes de inicio.
*                   
****************************************************************/
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.layout.AnchorPane;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
//fim da listagem de importacoes de bibliotecas utilizadas

public class Principal extends Application
{
  NaveDireita ndThread; //instancia a thread da nave direita
  NaveEsquerda neThread; //instanceia a thread da nave esquerda

  public static void main(String[] args)
  {
    launch(args);
  }
  //main iniciando o javaFX

  @Override
  /***************************************************************
   * Metodo: start
   * Funcao: Comeca o javaFX
   * Parametros:
   * - primaryStage: tela inicial do programa
   * Retorno: void
   ******************************************************************/
  public void start(Stage primaryStage) throws Exception
  {
  //primeiramente o botao de inicio e aparencia da tela --------------------------------------------------------

    Stage window = primaryStage; //atribuimos a variavel window ao primaryStage, para facilitar a leitura do codigo

    window.setTitle("Star Trains"); //Cria um stage para tela de inicio

    Image telainicio = new Image("file:Img/Star-wars-logo.jpg"); //define qual imagem sera utilizada na tela incial
    ImageView telainicio_view = new ImageView(telainicio); //cria um imageview dessa imagem

    telainicio_view.setFitHeight(900*0.83);// define a altura da imagem
    telainicio_view.setFitWidth(900*0.83);// define a largura da imagem

    AnchorPane layout = new AnchorPane(); //cria um painel para janela
    layout.getChildren().add(telainicio_view); //adiciona a imagem ao layout

    Button button = new Button(); //cria um botao
    button.setText("Comecar"); //adiciona o texto do botao
    layout.getChildren().add(button); //adciona o botao ao layout

    button.setPrefWidth(100); //define a largura do botao
    button.setPrefHeight(50); //define a altura do botao

    Scene scene = new Scene(layout); //cria uma cena para ser setada na janela
    window.setScene(scene); //seta a cena definida

    Image icon = new Image("file:Img/Star-wars-logo.jpg"); //define a imagem que sera usada no icone da pagina
    window.getIcons().add(icon); //adiciona o icone definido na pagina

    AnchorPane.setTopAnchor(button, 750.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(button, 400.0*0.83); //define a largura que o botao vai estar

    Image secondScreen = new Image("file:Img/telainicio.jpeg"); //cria outra imagem para ser usada na proxima janela
    ImageView secondScreen_view = new ImageView(secondScreen); //cria um imageview para o layout2

    AnchorPane layout2  = new AnchorPane(); // cria o segundo layout para proxima janela
    layout2.getChildren().add(secondScreen_view); //adiciona a imagem ao segundo layout

    secondScreen_view.setFitHeight(900*0.83);// define a altura da imagem
    secondScreen_view.setFitWidth(900*0.83);// define a largura da imagem

    Scene scene2 = new Scene(layout2); //cria a proxima janela

    button.setOnAction(e -> window.setScene(scene2)); //muda para a proxima janela

    AnchorPane layout3  = new AnchorPane(); //cria um novo layout para nova cena
    Scene scene3 = new Scene(layout3); //cria a cena dos trilhos

    Image espaco = new Image("Img/espaco.png");
    ImageView espaco_view = new ImageView(espaco);

    espaco_view.setFitHeight(900*0.83);// define a altura da imagem
    espaco_view.setFitWidth(900*0.83);// define a largura da imagem

    layout3.getChildren().add(espaco_view); //adiciona uma imagem ao layout
    
    //agora a criacao de 4 botoes para selecionar os possiveis caminhos--------------------------------------------------------------------------------------------

    Button path1 = new Button(); //cria um botao
    path1.setText("Millenium Falcon em baixo e X-Wing em cima"); //adiciona o texto ao botao
    layout2.getChildren().add(path1); //adiciona o botao ao layout

    path1.setPrefHeight(50); //define a altura do botao
    path1.setPrefWidth(500); //define a largura do botao

    AnchorPane.setTopAnchor(path1, 250.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path1, 150.0*0.83); //define a largura que o botao vai estar   

    Button path2 = new Button(); //cria um botao
    path2.setText("Millenium Falcon em cima e X-Wing em baixo"); //adiciona o texto ao botao
    layout2.getChildren().add(path2); //adiciona o botao ao layout

    path2.setPrefHeight(50); //define a altura do botao
    path2.setPrefWidth(500); //define a largura do botao

    AnchorPane.setTopAnchor(path2, 350.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path2, 150.0*0.83); //define a largura que o botao vai estar 

    Button path3 = new Button(); //cria um botao
    path3.setText("As duas naves em cima"); //adiciona o texto ao botao
    layout2.getChildren().add(path3); //adiciona o botao ao layout

    path3.setPrefHeight(50); //define a altura do botao
    path3.setPrefWidth(200); //define a largura do botao

    AnchorPane.setTopAnchor(path3, 450.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path3, 325.0*0.83); //define a largura que o botao vai estar 

    Button path4 = new Button(); //cria um botao
    path4.setText("As duas naves em baixo"); //adiciona o texto ao botao
    layout2.getChildren().add(path4); //adiciona o botao ao layout

    path4.setPrefHeight(50); //define a altura do botao
    path4.setPrefWidth(200); //define a largura do botao

    AnchorPane.setTopAnchor(path4, 550.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(path4, 325.0*0.83); //define a largura que o botao vai estar 

    //agora o andamento e controle dos trens (naves) junto as escolhas possiveis -----------------------------------------------------------------------------------------

    Image mf = new Image("Img/starwarsmillenniumfalcon3.png"); //imagem da milennium falcon
    Image xwing = new Image("Img/230911103258-01-star-wars-starfighter-model.png"); //imagem da x-wing

    ImageView mf_view = new ImageView(mf); //cria o view da milennium falcon
    ImageView xwing_view = new ImageView(xwing); //cria o view da xwing

    layout3.getChildren().add(mf_view); //adiciona a milennium falcon no layout

    mf_view.setFitHeight(100*0.83);// define a altura da imagem
    mf_view.setFitWidth(100*0.83);// define a largura da imagem

    layout3.getChildren().add(xwing_view); //adiciona a x-wing no layout

    xwing_view.setFitHeight(100*0.83);// define a altura da imagem
    xwing_view.setFitWidth(100*0.83);// define a largura da imagem

    //agora um botao para retornar para pagina anterior ----------------------------------------------------------------------------------

    Button back = new Button(); //cria um botao para retornar para cena anterior
    back.setText("Voltar"); //define o texto do botao
    layout3.getChildren().add(back); //adiciona o botao ao layout

    back.setPrefWidth(100); //define a largura do botao
    back.setPrefHeight(50); //define a altura do botao

    AnchorPane.setTopAnchor(back, 550.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(back, 750.0*0.83); //define a largura que o botao vai estar

    Button back2 = new Button(); //cria um botao para retornar para cena anterior
    back2.setText("Voltar"); //define o texto do botao
    layout2.getChildren().add(back2); //adiciona o botao ao layout

    back2.setOnAction(e -> window.setScene(scene)); //faz voltar uma cena

    back.setPrefWidth(100); //define a largura do botao
    back.setPrefHeight(50); //define a altura do botao

    AnchorPane.setTopAnchor(back2, 550.0*0.83); //define a alutra que o botao vai estar
    AnchorPane.setLeftAnchor(back2, 750.0*0.83); //define a largura que o botao vai estar

     //agora o botao de resetar o programa -----------------------------------------------------------------------------------------------

    Button reset = new Button(); //cria o botao para resetar a animacao
    reset.setText("Reiniciar 1 nave por vez"); //adiciona o texto ao botao
    layout3.getChildren().add(reset); //adiciona o botao ao layout do espaco

    AnchorPane.setTopAnchor(reset, 0.0*0.83); //define a alutra que o botao reset vai estar
    AnchorPane.setLeftAnchor(reset, 670.0*0.83); //define a largura que o botao reset vai estar
    //agora o slider de controle de velocidade --------------------------------------------------------------------------------------------

    Slider sliderMF = new Slider(); //cria o slider para milennium falcon
    sliderMF.setMin(0); //define o valor minimo da velocidade
    sliderMF.setMax(100); //define o valor maximo da velocidade

    Slider sliderX = new Slider(); // cria o slider para x-wing
    sliderX.setMin(0); //define o valor minimo da velocidade
    sliderX.setMax(100); //define o valor maximo da velocidade

    layout3.getChildren().add(sliderMF); //adiciona o slider da milennium falcon ao layout 
    layout3.getChildren().add(sliderX); //adiciona o slider da x-wing ao layout 

    AnchorPane.setTopAnchor(sliderMF, 850.0*0.83); //define a alutra que o slider da milennium falcon vai estar
    AnchorPane.setLeftAnchor(sliderMF, 0.0*0.83); //define a largura que o slider da milennium falcon vai estar

    AnchorPane.setTopAnchor(sliderX, 850.0*0.83); //define a alutra que o slider da x-wing vai estar
    AnchorPane.setLeftAnchor(sliderX, 725.0*0.83); //define a largura que o slider da x-wing vai estar

    sliderMF.setShowTickMarks(true); //mostra as marcacoes ao longo do slider
    sliderMF.setShowTickLabels(true); //mostra os numeros ao longo do slider

    sliderX.setShowTickLabels(true); //mostra os numeros ao longo do slider
    sliderX.setShowTickMarks(true); //mostra as marcacoes ao longo do slider

    back.setOnAction(e ->{
      neThread.stop(); //para a thread da nave esquerda
      ndThread.stop(); //para a thread da nave direita
      window.setScene(scene2); //muda a cena para selecao de caminhos
    });
    //determina a rotina de acoes ao apertar o botao de voltar na tela das naves

    //agora o codigo para selecionar os possiveis caminhos ------------------------------------------------------------------------------

    path1.setOnAction(e -> {
      neThread = new NaveEsquerda(mf_view, 1, 75.0*0.83, 775.0*0.83, true, scene3, window, sliderMF, reset, back, scene2, false);
      ndThread = new NaveDireita(xwing_view, 1, 500.0*0.83, 10.0*0.83, true, scene3, window, sliderX, reset, back, scene2, true);
      //inicializa os construtores das naves

      neThread.start(); //starta a thread da nave esquerda
      ndThread.start(); //starta a thread da nave direita
      //incia a animacao na posicao 1
    });

    path2.setOnAction(e -> {
      neThread = new NaveEsquerda(mf_view, 1, 100.0*0.83, 10.0*0.83, true, scene3, window, sliderMF, reset, back, scene2, true);
      ndThread = new NaveDireita(xwing_view, 1, 550.0*0.83, 775.0*0.83, true, scene3, window, sliderX, reset, back, scene2, false);
      //inicializa os construtores das naves

      neThread.start(); //starta a thread da nave esquerda
      ndThread.start(); //starta a thread da nave direita
      //incia a animacao na posicao 2
    });

    path3.setOnAction(e -> {
      neThread = new NaveEsquerda(xwing_view, 1, 100.0*0.83, 10.0*0.83, true, scene3, window, sliderMF, reset, back, scene2, true);
      ndThread = new NaveDireita(mf_view, 1, 500.0*0.83, 10.0*0.83, true, scene3, window, sliderX, reset, back, scene2, true);
      //inicializa os construtores das naves

      neThread.start(); //starta a thread da nave esquerda
      ndThread.start(); //starta a thread da nave direita
      //incia a animacao na posicao 3
    });

    path4.setOnAction(e -> {
      neThread = new NaveEsquerda(xwing_view, 1, 125.0*0.83, 775.0*0.83, true, scene3, window, sliderMF, reset, back, scene2, false);
      ndThread = new NaveDireita(mf_view, 1, 450.0*0.83, 775.0*0.83, true, scene3, window, sliderX, reset, back, scene2, false);
      //inicializa os construtores das naves

      neThread.start(); //starta a thread da nave esquerda
      ndThread.start(); //starta a thread da nave direita
      //incia a animacao na posicao 4
    });

    window.show(); //mostra a tela ao usuario
    window.setResizable(false);// impede o usuario de redimensionar a janela
  }
}