/****************************************************************
* Autor............: Lucas de Menezes Chaves
* Matricula........: 202310282
* Inicio...........: 05/05/2024
* Ultima alteracao.: 26/05/2024
* Nome.............: Nave Esquerda
* Funcao...........: O programa tem a funcao de simular o andamento e controle de um trem (nave), em diferentes posicoes de inicio.
****************************************************************/
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.application.Platform;
//fim da listagem de importacoes de bibliotecas utilizadas

public class NaveEsquerda extends Thread{
  public ImageView image; //cria uma variavel que recebe a imagem da nave esquerda
  public double vel; //cria uma variavel que atribui velocidade a nave esquerda
  private double posY; //posicao inicial Y
  private double posX; //posicao inicial X
  private double pontoParametro = 650.0*0.83; //ponto para parametrizar os calculos de posicao
  private boolean direcao; //direcao que a nave vai seguir
  public Scene scene; //variavel para receber a cena para efetuar a troca de tela
  public Scene scene2; //variavel para receber outra cena para efetuar a troca de tela
  public Stage stage; //variavel para receber o stage para efetuar a troca de tela
  public Slider slider; //variavel para receber o slider para controlar a velocidade
  public Button reset; //variavel para receber o botao de reset
  public Button back; //variavel para receber o botao de voltar
  public boolean swap; //variavel para identificar se o caminho e para cima ou para baixo
  private double zonaCritica1 = pontoParametro; //variavel que determina o local das zonas criticas (possivel colisao)
  private double zonaCritica2 = pontoParametro - 700.0 *0.83; //variavel que determina o local das zonas criticas (possivel colisao)
  public int x; //variavel que mostra a opcao de anticolisao escolhida
  public NaveDireita nd; //objeto da outra nave
  public int VT = 0; //variavel de travamento
  public int VEZ = 0; //estrita alternancia
  public int vez; //solucao de peterson
  public boolean interesse[] = {false,false}; //solucao de peterson
  public int option; //indica a opcao de caminho escolhida pelo usuario
  private boolean b; //variavel para guardar a verificacao de encontro de baixo
  private boolean c; //variavel para guardar a verificacao de encontro de cima
  private int processo; //processo utilizado na solucao de peterson
  //criacao de um construtor para nossa thread

  public NaveEsquerda(ImageView image, double vel, double posX, double posY, boolean direcao, Scene scene, Stage stage, Slider slider,
  Button reset, Button back, Scene scene2, boolean swap, int x, NaveDireita nd, int option){
    this.image = image;
    this.vel = vel;
    this.posX = posX;
    this.posY = posY;
    this.scene = scene;
    this.scene2 = scene2;
    this.stage = stage;
    this.direcao = direcao;
    this.reset = reset;
    this.back = back;
    this.swap = swap;
    this.slider = slider;
    this.x = x;
    this.nd = nd;
    this.option = option;
    //fim da atribuicao de variaveis ao construtor
  }

  /***************************************************************
   * Metodo: run
   * Funcao: Comeca a thread e faz a nave esquerda se movimentar
   * Parametros:
   * - nenhum
   * Retorno: void
   ******************************************************************/
  public void run(){
    Platform.runLater(() -> {
      image.setLayoutX(posX); //coloca a imagem na posicao inicial X
      image.setLayoutY(posY); //coloca a imagem na posicao inicial Y
      stage.setScene(scene); //muda a cena para a cena dos trilhos
      direcao = true;
      slider.setValue(10); //zera o valor do slider
    });
    //incio de um while que da o movimento a nave
    while(true){
      Platform.runLater(() -> {
        slider.valueProperty().addListener(new ChangeListener<Number>()
        {
          @Override
          public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
            double t1 = newValue.doubleValue(); //cria uma variavel que recebe o valor do slider
            double duration = (t1/30); //recalcula a velocidade da animacao e guarda em uma variavel
            vel = duration; //faz a velocidade ser atualizada
            //termina a rotina de acoes depois de ter regulado a velocidade
          }
        });
        //faz o slider controlar a duracao da animacao (sua velocidade)

        reset.setOnAction(e -> {
          image.setLayoutX(posX); //coloca a imagem na posicao inicial X
          image.setLayoutY(posY); //coloca a imagem na posicao inicial Y
          stage.setScene(scene); //muda a cena para a cena dos trilhos
          direcao = true;
          slider.setValue(0); //zera o valor do slider
        });//botao de reset

        if(swap == false){
          if(direcao == true){
            image.setLayoutY(image.getLayoutY() - vel);
            if(image.getLayoutY() <= pontoParametro){
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 125.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 250.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 515.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() <= pontoParametro - 700.0 *0.83){
              image.setLayoutY(image.getLayoutY() - vel);
              image.setLayoutY(posY);
              image.setLayoutX(posX);
              direcao = true;
            } //move a nave no eixo Y
          }
          if(direcao == false){
            image.setLayoutY(image.getLayoutY() - vel);
            image.setLayoutX(image.getLayoutX() + vel);
            if(image.getLayoutY() <= pontoParametro - 150.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() <= pontoParametro - 350.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() <= pontoParametro - 500.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() <= pontoParametro - 700.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
          }
        }
        else
        {
          if(direcao == true){
            image.setLayoutY(image.getLayoutY() + vel);
            if(image.getLayoutY() >= pontoParametro - 500.0){
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() >= pontoParametro - 400.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() >= pontoParametro - 250.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() >= pontoParametro){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = false;
            } //move a nave no eixo Y
            if(image.getLayoutY() >= pontoParametro + 100.0 *0.83){
              image.setLayoutY(image.getLayoutY() - vel);
              image.setLayoutY(posY);
              image.setLayoutX(posX);
              direcao = true;
            } //move a nave no eixo Y
          }
          if(direcao == false){
            image.setLayoutY(image.getLayoutY() + vel);
            image.setLayoutX(image.getLayoutX() + vel);
            if(image.getLayoutY() >= pontoParametro - 480.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() >= pontoParametro - 350.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() >= pontoParametro - 100.0 *0.83){
              image.setLayoutX(image.getLayoutX() - vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
            if(image.getLayoutY() >= pontoParametro + 75.0 *0.83){
              image.setLayoutX(image.getLayoutX() + vel);
              direcao = true;
            } //move a nave no eixo Y e no eixo X
          }
        }
      });
  
      switch(x)
      {
        case 1: //variavel de travamento
          VT = 0; //define o valor 0 para variavel de travamento
          while(encontro() == true){
            VT = 1; //define o valor 1, ou seja, indica que o trilho esta ocupado
            rc(); //chama a funcao de regiao critica
          }
          VT = 0; //retorna o valor da variavel de treinamento para 0, indicando que o trilho esta livre novamente
          rnc(); // chama a funcao de regiao nao critica
          break; //quebra o caso 1 do switch
        case 2: //estrita alternancia
          while(nd.encontro() == false && encontro() == true){
            VEZ = 1;
            while(VEZ != 0){
              nd.rc(); 
            }
          }
          VEZ = 0;
          break;
        case 3: //solucao de peterson
          while(encontro() == true){
            processo = 1;
            entrarRC(processo);
          }
          deixarRC(processo);
          break;
      }
      //um switch que determina o que cada escolha de anti colisao faz

        try{
          Thread.sleep(10); //pausa o funcionamento da thread para fluidez do programa
        }
        catch(InterruptedException e)
        {
        e.printStackTrace();
        }
      }
    }
  /***************************************************************
   * Metodo: rc
   * Funcao: Define a velocidade em regioes criticas
   * Parametros:
   * - nenhum
   * Retorno: void
   ******************************************************************/
    public void rc(){
      vel = 0;
    }
  /***************************************************************
   * Metodo: rnc
   * Funcao: Define a velocidade em regioes nao criticas
   * Parametros:
   * - nenhum
   * Retorno: void
   ******************************************************************/
    public void rnc(){
      vel = 1;
    }
  /***************************************************************
   * Metodo: encontro
   * Funcao: verifica se as naves vao se encontrar na primeira zona critica
   * Parametros:
   * - nenhum
   * Retorno: boolean
   ******************************************************************/
  public boolean encontro(){
    if(option == 1){
      if((image.getLayoutY() <= zonaCritica1 + 90.0* 0.83) && (nd.image.getLayoutY() >= zonaCritica1 - 90.0 * 0.83)){
        b = true;
      }//um if para saber se as duas naves possuem risco de se colidirem na primeira zona critica 
      if((image.getLayoutY() >= zonaCritica2) && (nd.image.getLayoutY() <= zonaCritica2)){
        c = true;
      }//um if para saber se as duas naves possuem risco de se colidirem na segunda zona critica
      if(b == c){
        return false;
      }
    } //para o caminho que a nave esquerda esta em baixo
    else if (option == 2){
      if((image.getLayoutY() <= zonaCritica1) && (nd.image.getLayoutY() >= zonaCritica1)){
        return true;
      }//um if para saber se as duas naves possuem risco de se colidirem na primeira zona critica
      if((image.getLayoutY() >= zonaCritica2) && (nd.image.getLayoutY() <= zonaCritica2)){
        return true;
      }//um if para saber se as duas naves possuem risco de se colidirem na segunda zona critica
    } //para o caminho em que a nave esquerda esta em cima
    else if (option == 3){
      if((image.getLayoutY() >= zonaCritica1) && (nd.image.getLayoutY() >= zonaCritica1)){
        return true;
      }//um if para saber se as duas naves possuem risco de se colidirem na primeira zona critica
      if((image.getLayoutY() <= zonaCritica2) && (nd.image.getLayoutY() <= zonaCritica2)){
        return true;
      }//um if para saber se as duas naves possuem risco de se colidirem na segunda zona critica
    } //para o caminho que a nave esquerda esta em cima com a direita
    else if(option == 4){
      if((image.getLayoutY() <= zonaCritica1) && (nd.image.getLayoutY() <= zonaCritica1)){
        return true;
      }//um if para saber se as duas naves possuem risco de se colidirem na primeira zona critica
      if((image.getLayoutY() >= zonaCritica2) && (nd.image.getLayoutY() >= zonaCritica2)){
        return true;
      }//um if para saber se as duas naves possuem risco de se colidirem na segunda zona critica
    } //para o caminho que a nave esquerda esta em baixo com a direita
    return false;
  }

  /***************************************************************
   * Metodo: entrarRC
   * Funcao: cuida da regiao critica na solucao de peterson
   * Parametros:
   * - processo (inteiro)
   * Retorno: void
   ******************************************************************/
  public void entrarRC(int processo){
    int outro;
    outro = 1 - processo;
    interesse[processo] = true;
    vez = processo;
    while(vez == processo && interesse[outro] == true){
      rc();
    }
  }
  /***************************************************************
   * Metodo: deixarRC
   * Funcao: cuida da regiao critica na solucao de peterson
   * Parametros:
   * - processo (inteiro)
   * Retorno: void
   ******************************************************************/
  public void deixarRC(int processo){
    interesse[processo] = false;
    rnc();
  }
}